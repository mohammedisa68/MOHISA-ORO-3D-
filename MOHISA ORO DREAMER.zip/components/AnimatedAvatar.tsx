
import React from 'react';

interface AnimatedAvatarProps {
  isSpeaking?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  mood?: 'neutral' | 'happy' | 'thinking';
}

const AnimatedAvatar: React.FC<AnimatedAvatarProps> = ({ isSpeaking = false, size = 'md', mood = 'happy' }) => {
  const sizeClasses = {
    sm: 'w-24 h-24',
    md: 'w-48 h-48',
    lg: 'w-64 h-64',
    xl: 'w-80 h-80 sm:w-96 sm:h-96'
  };

  return (
    <div className={`relative ${sizeClasses[size]} mx-auto group`}>
      {/* Cinematic Environmental Glow */}
      <div className={`absolute inset-0 bg-cyan-400/20 rounded-full blur-[100px] transition-all duration-1000 ${isSpeaking ? 'opacity-80 scale-125' : 'opacity-30 scale-100'}`}></div>
      
      <svg
        viewBox="0 0 200 250"
        className="w-full h-full relative z-10 drop-shadow-[0_30px_50px_rgba(0,0,0,0.3)] animate-robot-float"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Glossy White Plastic Gradient */}
          <linearGradient id="robotWhite" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="60%" stopColor="#F1F5F9" />
            <stop offset="100%" stopColor="#CBD5E1" />
          </linearGradient>

          {/* Chrome / Metallic Gradient */}
          <linearGradient id="robotChrome" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#94A3B8" />
            <stop offset="50%" stopColor="#F8FAFC" />
            <stop offset="100%" stopColor="#475569" />
          </linearGradient>

          {/* Dark Glass Visor */}
          <linearGradient id="robotVisor" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#0F172A" />
            <stop offset="100%" stopColor="#000000" />
          </linearGradient>
          
          <filter id="glowEffect" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>

          <clipPath id="visorClip">
            <ellipse cx="100" cy="80" rx="65" ry="50" />
          </clipPath>
        </defs>

        {/* Arms - Metallic Joints */}
        <g className="animate-arms-swing">
          {/* Left Arm */}
          <rect x="35" y="145" width="15" height="40" rx="7.5" fill="url(#robotWhite)" />
          <circle cx="42.5" cy="140" r="10" fill="url(#robotChrome)" />
          {/* Right Arm */}
          <rect x="150" y="145" width="15" height="40" rx="7.5" fill="url(#robotWhite)" />
          <circle cx="157.5" cy="140" r="10" fill="url(#robotChrome)" />
        </g>

        {/* Body - Spherical */}
        <circle cx="100" cy="180" r="50" fill="url(#robotWhite)" stroke="#E2E8F0" strokeWidth="1" />
        <path d="M70 180 Q100 200 130 180" stroke="#CBD5E1" strokeWidth="2" fill="none" opacity="0.5" />
        
        {/* Legs / Base Units */}
        <rect x="65" y="215" width="25" height="15" rx="7.5" fill="url(#robotChrome)" />
        <rect x="110" y="215" width="25" height="15" rx="7.5" fill="url(#robotChrome)" />

        {/* Neck Joint */}
        <rect x="85" y="125" width="30" height="10" rx="5" fill="url(#robotChrome)" />

        {/* Head - Large Spherical */}
        <circle cx="100" cy="80" r="75" fill="url(#robotWhite)" stroke="#E2E8F0" strokeWidth="1" />
        
        {/* Visor Area */}
        <ellipse cx="100" cy="80" rx="65" ry="50" fill="url(#robotVisor)" />
        
        {/* Visor Reflection */}
        <path 
           d="M60 55 Q100 45 140 55" 
           stroke="white" 
           strokeWidth="8" 
           strokeLinecap="round" 
           opacity="0.1" 
           clipPath="url(#visorClip)" 
        />

        {/* Digital Face - Glowing Cyan */}
        <g filter="url(#glowEffect)">
          {/* Left Eye */}
          <path 
            d="M65 75 Q75 65 85 75" 
            stroke="#22D3EE" 
            strokeWidth="5" 
            strokeLinecap="round" 
            fill="none" 
            className={isSpeaking ? 'animate-eye-pulse' : ''}
          />
          {/* Right Eye */}
          <path 
            d="M115 75 Q125 65 135 75" 
            stroke="#22D3EE" 
            strokeWidth="5" 
            strokeLinecap="round" 
            fill="none" 
            className={isSpeaking ? 'animate-eye-pulse' : ''}
          />
          {/* Smile / Speaking Mouth */}
          <path 
            d={isSpeaking ? "M85 105 Q100 115 115 105" : "M90 105 H110"} 
            stroke="#22D3EE" 
            strokeWidth="4" 
            strokeLinecap="round" 
            fill="none" 
            className={isSpeaking ? 'animate-mouth-talk' : ''}
          />
        </g>

        {/* Ear/Sensor Detail */}
        <circle cx="25" cy="80" r="10" fill="url(#robotChrome)" />
        <circle cx="25" cy="80" r="4" fill="#22D3EE" className="animate-pulse" filter="url(#glowEffect)" />
        <circle cx="175" cy="80" r="10" fill="url(#robotChrome)" />
        <circle cx="175" cy="80" r="4" fill="#22D3EE" className="animate-pulse" filter="url(#glowEffect)" />

      </svg>

      <style>{`
        @keyframes robot-float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-15px); }
        }
        .animate-robot-float {
          animation: robot-float 5s ease-in-out infinite;
        }

        @keyframes arms-swing {
          0%, 100% { transform: rotate(-2deg); }
          50% { transform: rotate(2deg); }
        }
        .animate-arms-swing {
          animation: arms-swing 4s ease-in-out infinite;
          transform-origin: center;
        }

        @keyframes mouth-talk {
          0%, 100% { d: path("M85 105 Q100 115 115 105"); stroke-width: 4; }
          50% { d: path("M80 105 Q100 125 120 105"); stroke-width: 6; }
        }
        .animate-mouth-talk {
          animation: mouth-talk 0.15s infinite;
        }

        @keyframes eye-pulse {
          0%, 100% { opacity: 1; transform: scaleY(1); }
          50% { opacity: 0.8; transform: scaleY(1.2); }
        }
        .animate-eye-pulse {
          animation: eye-pulse 0.2s infinite;
          transform-origin: 75px 75px;
        }
      `}</style>
    </div>
  );
};

export default AnimatedAvatar;
