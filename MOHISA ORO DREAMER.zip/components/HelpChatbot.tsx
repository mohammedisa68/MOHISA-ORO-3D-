
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Language } from '../types';

interface Message {
  role: 'user' | 'model';
  text: string;
}

interface HelpChatbotProps {
  language: Language;
}

const HelpChatbot: React.FC<HelpChatbotProps> = ({ language }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const suggestions = language === Language.OROMO ? [
    "Waa'ee Voice AI?",
    "Image AI akkamin hojjeta?",
    "Video AI maali?",
    "Mohammed Isa eenyu?",
    "Kaffaltii akkamin raawwadha?"
  ] : [
    "What is Voice AI?",
    "How does Image AI work?",
    "Tell me about Video AI",
    "Who is Mohammed Isa?",
    "How do I pay?"
  ];

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async (textOverride?: string) => {
    const messageText = textOverride || input;
    if (!messageText.trim() || isTyping) return;

    const userMsg: Message = { role: 'user', text: messageText };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const systemInstruction = `You are "MOHISA ORO AI MASTER HELPER". You are the ultimate assistant for the MOHISA ORO platform created by Mohammed Isa.
      Features you know about:
      - TTS (Text to Speech): Natural Afaan Oromo voices (Male/Female).
      - STT (Speech to Text): Transcribing Oromo speech.
      - Image AI: Generating and editing cinematic Oromo cultural images.
      - Video AI: Creating animations from images and text.
      - Live Chat: Real-time AI conversation and bidirectional translation.
      - Gift Market: Virtual trading of Odaa, Baallii, and Barcuma assets.
      - Payment: Supporting Telebirr, MasterCard, and PayPal.
      
      Personality: Professional, inspiring, and deeply knowledgeable about Oromo culture.
      Language: Respond primarily in ${language === Language.OROMO ? 'Afaan Oromoo' : 'English'}.
      Note: Mohammed Isa is a visionary developer and the creator of this entire ecosystem. 
      Format: Always structure your responses into short, clear paragraphs for readability.`;

      const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [...messages, userMsg].map(m => ({
          role: m.role,
          parts: [{ text: m.text }]
        })),
        config: {
          systemInstruction,
          temperature: 0.8,
        }
      });

      const modelText = response.text || (language === Language.OROMO ? "Maaloo dhiifama, deebii argachuu hin dandeenye." : "Sorry, I couldn't get a response.");
      setMessages(prev => [...prev, { role: 'model', text: modelText }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: "Connection error. Please check your internet." }]);
    } finally {
      setIsTyping(false);
    }
  };

  const renderTextWithParagraphs = (text: string, isModel: boolean) => {
    const paragraphs = text.split(/\n+/).filter(p => p.trim() !== '');
    
    return (
      <div className="space-y-4">
        {paragraphs.map((p, idx) => (
          <p 
            key={idx} 
            className={`animate-in fade-in slide-in-from-bottom-2 duration-500 fill-mode-both`}
            style={{ animationDelay: `${idx * 150}ms` }}
          >
            {p.trim()}
          </p>
        ))}
      </div>
    );
  };

  return (
    <div className="relative flex flex-col items-end">
      {isOpen && (
        <div className="fixed bottom-32 sm:bottom-40 right-6 sm:right-10 w-[320px] sm:w-[500px] h-[60vh] sm:h-[700px] bg-white rounded-[3rem] sm:rounded-[4rem] shadow-[0_50px_120px_-20px_rgba(0,0,0,0.4)] border border-slate-100 flex flex-col overflow-hidden animate-in slide-in-from-bottom-12 zoom-in-95 duration-500 z-[700]">
          <div className="bg-gradient-to-br from-black via-slate-900 to-slate-800 p-8 sm:p-10 text-white relative shrink-0">
            <div className="absolute top-0 right-0 w-32 h-32 bg-red-600/20 rounded-full blur-3xl -mr-16 -mt-16"></div>
            <div className="flex items-center justify-between relative z-10">
              <div className="flex items-center gap-4 sm:gap-5">
                <div className="w-12 h-12 sm:w-16 sm:h-16 bg-white/10 backdrop-blur-xl rounded-[1.2rem] sm:rounded-[1.5rem] flex items-center justify-center border border-white/20 shadow-2xl">
                   <span className="text-2xl sm:text-3xl animate-pulse">🤖</span>
                </div>
                <div>
                  <h4 className="font-black text-[10px] sm:text-sm uppercase tracking-[0.3em] leading-none">MOHISA HELPER</h4>
                  <p className="text-[8px] sm:text-[10px] font-bold text-emerald-400 uppercase tracking-widest mt-2 flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
                    Online
                  </p>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="w-10 h-10 hover:bg-white/10 rounded-full flex items-center justify-center transition-all text-xl">✕</button>
            </div>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-6 sm:space-y-8 no-scrollbar bg-slate-50/20">
            {messages.length === 0 && (
              <div className="text-center py-6 sm:py-10 space-y-6 sm:space-y-10 animate-in fade-in duration-1000">
                <div className="space-y-4">
                  <div className="w-20 h-20 sm:w-28 sm:h-28 bg-white rounded-[2rem] sm:rounded-[2.5rem] flex items-center justify-center mx-auto text-4xl sm:text-6xl shadow-2xl border border-slate-50 rotate-3 transition-transform hover:rotate-0 duration-500">👋</div>
                  <h5 className="text-2xl sm:text-3xl font-black tracking-tighter text-slate-900 uppercase italic">
                    {language === Language.OROMO ? "Baga Nagaan Dhufte!" : "Welcome!"}
                  </h5>
                </div>

                <div className="flex flex-wrap justify-center gap-2 px-2">
                  {suggestions.map((s, i) => (
                    <button 
                      key={i}
                      onClick={() => handleSend(s)}
                      className="px-4 py-3 bg-white border border-slate-100 rounded-2xl text-[9px] font-black uppercase tracking-widest text-slate-600 hover:bg-black hover:text-white transition-all shadow-sm"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-4 duration-500`}>
                <div className={`max-w-[90%] p-5 sm:p-7 rounded-[1.8rem] sm:rounded-[2.5rem] text-[13px] sm:text-[14px] font-medium leading-relaxed shadow-sm transition-all ${
                  m.role === 'user' 
                    ? 'bg-black text-white rounded-tr-none shadow-xl' 
                    : 'bg-white text-slate-800 border border-slate-100 rounded-tl-none ring-1 ring-black/5'
                }`}>
                  {renderTextWithParagraphs(m.text, m.role === 'model')}
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start animate-in fade-in duration-300">
                <div className="bg-white p-5 rounded-[1.5rem] rounded-tl-none border border-slate-100 flex gap-1.5 items-center shadow-sm">
                  <div className="w-2 h-2 bg-red-600 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-red-600 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                  <div className="w-2 h-2 bg-red-600 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                </div>
              </div>
            )}
          </div>

          <div className="p-6 sm:p-8 bg-white border-t border-slate-100 shadow-[0_-10px_40px_rgba(0,0,0,0.02)] shrink-0">
            <div className="relative group">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder={language === Language.OROMO ? "Gaaffii kee barreessi..." : "Ask me..."}
                className="w-full p-5 sm:p-7 pr-16 sm:pr-20 bg-slate-50 border-2 border-slate-100 rounded-[1.5rem] sm:rounded-[2rem] outline-none focus:border-red-600 focus:bg-white transition-all font-bold text-[10px] sm:text-xs uppercase tracking-widest placeholder:text-slate-300"
              />
              <button 
                onClick={() => handleSend()}
                disabled={isTyping || !input.trim()}
                className="absolute right-2 top-1/2 -translate-y-1/2 w-12 h-12 sm:w-16 sm:h-16 bg-black text-white rounded-xl sm:rounded-[1.4rem] flex items-center justify-center hover:bg-red-600 transition-all disabled:opacity-30 active:scale-90 shadow-2xl"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Trigger Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={`w-14 h-14 sm:w-16 sm:h-16 rounded-[1.5rem] sm:rounded-[1.8rem] shadow-2xl flex flex-col items-center justify-center transition-all active:scale-90 relative group overflow-hidden border-2 border-white ${isOpen ? 'bg-black text-white rotate-[15deg]' : 'bg-white text-black'}`}
      >
        <span className="text-2xl sm:text-3xl group-hover:scale-110 transition-transform duration-500">{isOpen ? '✕' : '🤖'}</span>
      </button>
    </div>
  );
};

export default HelpChatbot;
