
import React, { useState } from 'react';
import { Language, LanguageNames } from '../types';
import { supabase } from '../supabase';
import AnimatedAvatar from './AnimatedAvatar';

interface LoginOverlayProps {
  onLanguageChange: (lang: Language) => void;
  currentLanguage: Language;
  onGuestLogin: () => void;
}

const LoginOverlay: React.FC<LoginOverlayProps> = ({ onLanguageChange, currentLanguage, onGuestLogin }) => {
  const [isLoginView, setIsLoginView] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const [formData, setFormData] = useState({
    emailOrPhone: '',
    password: ''
  });

  const translations: Record<Language, any> = {
    [Language.OROMO]: {
      loginTitle: 'Seeni',
      signUpTitle: 'Account Uumi',
      emailPhone: 'Email (Gmail)',
      password: 'Jecha Icctii',
      loginBtn: 'SEENI',
      signUpBtn: 'ACCOUNT UUMI',
      freeLoginBtn: 'BILISA SEENI (GUEST)',
      googleBtn: 'GMAIL\'N SEENI',
      forgot: 'Password dagattee?',
      noAccount: 'Account hin qabduu? Sign Up',
      haveAccount: 'Account qabduu? Seeni',
      required: 'Maaloo hunda guuti!',
      passShort: 'Password characters 6 gadi ta\'uu hin qabu!',
      success: 'Account milkaayinaan uumameera!',
      error: 'Email yookiin Password dogoggora!'
    },
    [Language.ENGLISH]: {
      loginTitle: 'Login',
      signUpTitle: 'Sign Up',
      emailPhone: 'Email (Gmail)',
      password: 'Password',
      loginBtn: 'LOGIN',
      signUpBtn: 'CREATE ACCOUNT',
      freeLoginBtn: 'FREE LOGIN (GUEST)',
      googleBtn: 'SIGN IN WITH GOOGLE',
      forgot: 'Forgot Password?',
      noAccount: "Don't have an account? Sign Up",
      haveAccount: 'Already have an account? Login',
      required: 'All fields are required!',
      passShort: 'Password must be at least 6 characters!',
      success: 'Account successfully created!',
      error: 'Invalid email or password!'
    },
    [Language.TURKISH]: {
      loginTitle: 'Giriş Yap',
      signUpTitle: 'Kayıt Ol',
      emailPhone: 'E-posta (Gmail)',
      password: 'Şifre',
      loginBtn: 'GİRİŞ',
      signUpBtn: 'HESAP OLUŞTUR',
      freeLoginBtn: 'ÜCRETSİZ GİRİŞ (MİSAFİR)',
      googleBtn: 'GOOGLE İLE GİRİŞ YAP',
      forgot: 'Şifremi Unuttum?',
      noAccount: 'Hesabınız yok mu? Kayıt Ol',
      haveAccount: 'Zaten hesabınız var mı? Giriş Yap',
      required: 'Tüm alanlar zorunludur!',
      passShort: 'Şifre en az 6 karakter olmalıdır!',
      success: 'Hesap başarıyla oluşturuldu!',
      error: 'Geçersiz e-posta veya şifre!'
    },
    [Language.SPANISH]: {
      loginTitle: 'Iniciar Sesión',
      signUpTitle: 'Registrarse',
      emailPhone: 'Correo (Gmail)',
      password: 'Contraseña',
      loginBtn: 'ENTRAR',
      signUpBtn: 'CREAR CUENTA',
      freeLoginBtn: 'ACCESO GRATIS (INVITADO)',
      googleBtn: 'INICIAR CON GOOGLE',
      forgot: '¿Olvidaste tu contraseña?',
      noAccount: '¿No tienes cuenta? Regístrate',
      haveAccount: '¿Ya tienes cuenta? Entra',
      required: '¡Todos los campos son obligatorios!',
      passShort: '¡La contraseña debe tener al menos 6 caracteres!',
      success: '¡Cuenta creada con éxito!',
      error: '¡Correo o contraseña inválidos!'
    },
    [Language.ARABIC]: {
      loginTitle: 'تسجيل الدخول',
      signUpTitle: 'إنشاء حساب',
      emailPhone: 'البريد الإلكتروني',
      password: 'كلمة المرور',
      loginBtn: 'دخول',
      signUpBtn: 'إنشاء حساب',
      freeLoginBtn: 'دخول مجاني (ضيف)',
      googleBtn: 'الدخول بجوجل',
      forgot: 'نسيت كلمة المرور؟',
      noAccount: 'ليس لديك حساب؟ سجل الآن',
      haveAccount: 'لديك حساب بالفعل؟ دخول',
      required: 'جميع الحقول مطلوبة!',
      passShort: 'يجب أن تكون كلمة المرور 6 أحرف على الأقل!',
      success: 'تم إنشاء الحساب بنجاح!',
      error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة!'
    },
    [Language.AMHARIC]: {
      loginTitle: 'ይግቡ',
      signUpTitle: 'አካውንት ይፍጠሩ',
      emailPhone: 'ኢሜይል',
      password: 'የይለፍ ቃል',
      loginBtn: 'ይግቡ',
      signUpBtn: 'አካውንት ይፍጠሩ',
      freeLoginBtn: 'በነጻ ይግቡ (እንግዳ)',
      googleBtn: 'በጎግል ይግቡ',
      forgot: 'የይለፍ ቃል ረስተዋል?',
      noAccount: 'አካውንት የለዎትም? ይመዝገቡ',
      haveAccount: 'አካውንት አለዎት? ይግቡ',
      required: 'እባክዎ ሁሉንም ይሙሉ!',
      passShort: 'የይለፍ ቃሉ ቢያንስ 6 ፊደላት መሆን አለበት!',
      success: 'አካውንቱ በተሳካ ሁኔታ ተፈጥሯል!',
      error: 'ኢሜይል ወይም የይለፍ ቃል ተሳስቷል!'
    },
    [Language.SWAHILI]: {
      loginTitle: 'Ingia',
      signUpTitle: 'Jisajili',
      emailPhone: 'Barua Pepe',
      password: 'Nenosiri',
      loginBtn: 'INGIA',
      signUpBtn: 'TENGENEZA AKAUNTI',
      freeLoginBtn: 'INGIA BILA MALIPO (MGENI)',
      googleBtn: 'INGIA NA GOOGLE',
      forgot: 'Umesahau Nenosiri?',
      noAccount: 'Hauna akaunti? Jisajili',
      haveAccount: 'Tayari una akaunti? Ingia',
      required: 'Sehemu zote zinahitajika!',
      passShort: 'Nenosiri lazima iwe angalau herufi 6!',
      success: 'Akaunti imetengenezwa kwa mafanikio!',
      error: 'Barua pepe au nenosiri si sahihi!'
    },
    [Language.SOMALI]: {
      loginTitle: 'Gali',
      signUpTitle: 'Is qor',
      emailPhone: 'Email',
      password: 'Ereyga sirta ah',
      loginBtn: 'GALI',
      signUpBtn: 'SAMAYSO ACCOUNT',
      freeLoginBtn: 'BILAASH KU GALI (MASHRIIC)',
      googleBtn: 'GOOGLE KU GALI',
      forgot: 'Ma ilowday ereyga sirta ah?',
      noAccount: 'Account ma haysatid? Is qor',
      haveAccount: 'Account ma haysataa? Gali',
      required: 'Fadlan buuxi dhammaan!',
      passShort: 'Ereyga sirta ah waa inuu ugu yaraan 6 xaraf ka kooban jay qay!',
      success: 'Account-ka si guul leh ayaa loo sameeyay!',
      error: 'Email-ka ama ereyga sirta ah waa qalad!'
    }
  };

  const t = translations[currentLanguage] || translations[Language.ENGLISH];

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const { emailOrPhone, password } = formData;

    if (!emailOrPhone || !password) {
      setErrorMsg(t.required);
      return;
    }

    if (!isLoginView && password.length < 6) {
      setErrorMsg(t.passShort);
      return;
    }

    setIsLoading(true);

    try {
      if (isLoginView) {
        const { error } = await supabase.auth.signInWithPassword({
          email: emailOrPhone.includes('@') ? emailOrPhone : `${emailOrPhone}@mohisa-user.com`,
          password,
        });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signUp({
          email: emailOrPhone.includes('@') ? emailOrPhone : `${emailOrPhone}@mohisa-user.com`,
          password,
        });
        if (error) throw error;
        setSuccessMsg(t.success);
        setTimeout(() => setIsLoginView(true), 2000);
      }
    } catch (err: any) {
      setErrorMsg(err.message || t.error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setIsLoading(true);
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: window.location.origin
        }
      });
      if (error) throw error;
    } catch (err: any) {
      setErrorMsg("Gmail Login requires Supabase OAuth setup. Try Guest login.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div 
      className="fixed inset-0 z-[500] flex flex-col items-center justify-center p-4 overflow-y-auto no-scrollbar"
      style={{ 
        background: 'linear-gradient(135deg, #00f5d4, #ff007f, #00f5d4, #ff007f)',
        backgroundSize: '400% 400%',
        animation: 'gradient-bg 15s ease infinite'
      }}
    >
      <div className="relative z-10 w-full max-w-md space-y-4 animate-in fade-in zoom-in-95 duration-700 py-6">
        
        <div className="flex justify-center mb-2 animate-slide-down">
          <div className="relative w-full max-w-[280px] group animate-lang-glow rounded-full overflow-hidden shadow-xl">
            <select 
              value={currentLanguage}
              onChange={(e) => onLanguageChange(e.target.value as Language)}
              className="w-full appearance-none bg-white/90 backdrop-blur-3xl border border-white px-10 py-3 rounded-full font-black text-[9px] uppercase tracking-widest text-black outline-none transition-all cursor-pointer text-center shadow-inner"
            >
              {Object.entries(LanguageNames).map(([code, name]) => (
                <option key={code} value={code} className="text-black text-sm font-bold">{name}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="glass-card rounded-[2.5rem] p-6 sm:p-10 relative overflow-hidden group shadow-2xl bg-white/95">
          <div className="relative z-10">
            <div className="text-center mb-6">
              <div className="mb-4 scale-75 group-hover:scale-80 transition-transform duration-700">
                <AnimatedAvatar size="sm" />
              </div>
              <h2 className="text-3xl font-black text-slate-900 tracking-tighter uppercase italic leading-none">
                {isLoginView ? t.loginTitle : t.signUpTitle}
              </h2>
            </div>

            <form onSubmit={handleAuth} className="space-y-4">
              <input 
                type="text" 
                name="emailOrPhone" 
                placeholder={t.emailPhone}
                value={formData.emailOrPhone} 
                onChange={handleChange} 
                className="w-full bg-slate-50 border border-slate-100 p-4 rounded-2xl outline-none focus:border-red-600 transition-all font-bold text-xs text-slate-900" 
              />

              <div className="relative">
                <input 
                  type={showPassword ? "text" : "password"} 
                  name="password" 
                  placeholder={t.password}
                  value={formData.password} 
                  onChange={handleChange} 
                  className="w-full bg-slate-50 border border-slate-100 p-4 pr-12 rounded-2xl outline-none focus:border-red-600 transition-all font-bold text-xs text-slate-900 tracking-widest" 
                />
                <button 
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400"
                >
                  {showPassword ? "👁️" : "🙈"}
                </button>
              </div>

              {errorMsg && (
                <div className="bg-red-50 text-red-600 p-3 rounded-xl text-[9px] font-black uppercase tracking-widest text-center border border-red-100">
                  {errorMsg}
                </div>
              )}

              {successMsg && (
                <div className="bg-emerald-50 text-emerald-600 p-3 rounded-xl text-[9px] font-black uppercase tracking-widest text-center border border-emerald-100">
                  {successMsg}
                </div>
              )}

              <div className="flex flex-col gap-3 pt-2">
                <button 
                  type="submit" 
                  disabled={isLoading} 
                  className="w-full py-4 bg-black text-white rounded-2xl font-black text-[11px] tracking-widest shadow-xl hover:bg-red-600 transition-all active:scale-95 border-b-4 border-slate-800"
                >
                  {isLoading ? "..." : (isLoginView ? t.loginBtn : t.signUpBtn)}
                </button>

                <button 
                  type="button"
                  onClick={handleGoogleLogin}
                  className="w-full py-3.5 bg-white border border-slate-100 text-slate-900 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow hover:bg-slate-50 transition-all flex items-center justify-center gap-2"
                >
                  <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-4 h-4" alt="G" />
                  {t.googleBtn}
                </button>

                <button 
                  type="button"
                  onClick={onGuestLogin}
                  className="w-full py-3 bg-slate-50 text-slate-500 rounded-2xl font-black text-[9px] uppercase tracking-widest hover:bg-slate-100 transition-all"
                >
                  {t.freeLoginBtn}
                </button>
              </div>
            </form>

            <div className="mt-6 text-center">
              <button 
                onClick={() => setIsLoginView(!isLoginView)} 
                className="text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-red-600 transition-all"
              >
                {isLoginView ? t.noAccount : t.haveAccount}
              </button>
            </div>
          </div>
        </div>
        
        <p className="text-center text-white/80 font-black text-[9px] uppercase tracking-[0.4em] italic">Invincible app</p>
      </div>
    </div>
  );
};

export default LoginOverlay;
