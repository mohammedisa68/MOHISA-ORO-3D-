
import React, { useEffect, useState } from 'react';
import { AppMode, Language } from '../types';

interface DashboardProps {
  onNavigate: (mode: AppMode) => void;
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate, currentLanguage }) => {
  const [isAppSelected, setIsAppSelected] = useState(false);
  const [isPremium, setIsPremium] = useState(() => localStorage.getItem('mohisa_premium') === 'true');

  useEffect(() => {
    const selected = localStorage.getItem('mohisa_app_selected') === 'true';
    setIsAppSelected(selected);
  }, []);

  const handleSelectApp = () => {
    const newState = !isAppSelected;
    setIsAppSelected(newState);
    localStorage.setItem('mohisa_app_selected', String(newState));
    
    const msg = currentLanguage === Language.OROMO 
      ? (newState ? "App koo filachuu keessaniif galatoomaa! 🌟" : "App filannoo keessanirraa haqameera.")
      : (newState ? "Thank you for selecting my app! 🌟" : "App removed from your selections.");
    
    alert(msg);
  };

  const labels = {
    om: {
      vision: "QAROOMINA",
      description: "Malkaa beekumsaa fi madda teeknoolojii, kan Afaan kee fi aadaa kee ammayyeessuuf dhufe.",
      filBtn: "APP KOO FILADHU",
      filBtnActive: "APP KOO FILATAMEERA",
      toolsTitle: "MEESHAALEE AI",
    },
    en: {
      vision: "INNOVATION",
      description: "A convergence of wisdom and technology, designed to modernize your language and culture.",
      filBtn: "SELECT MY APP",
      filBtnActive: "APP SELECTED",
      toolsTitle: "AI TOOLS",
    }
  }[currentLanguage === Language.OROMO ? 'om' : 'en'] || {
    vision: "INNOVATION",
    description: "A convergence of wisdom and technology, designed to modernize your language and culture.",
    filBtn: "SELECT MY APP",
    filBtnActive: "APP SELECTED",
    toolsTitle: "AI TOOLS",
  };

  const tools = [
    { mode: AppMode.TTS, title: { om: 'Sagalee AI', en: 'Voice AI' }, icon: '🗣️', color: 'from-red-500 to-red-900', desc: { om: 'Text to Speech', en: 'Text to Speech' } },
    { mode: AppMode.STT, title: { om: 'Transcribe AI', en: 'STT AI' }, icon: '🎙️', color: 'from-amber-400 to-orange-600', desc: { om: 'Speech to Text', en: 'Speech to Text' } },
    { mode: AppMode.COMMUNICATION, title: { om: 'Live walin Mohisa', en: 'Live with Mohisa' }, icon: '💬', color: 'from-indigo-600 to-purple-900', desc: { om: 'Real-time Chat', en: 'Real-time Chat' } },
    { mode: AppMode.IMAGE, title: { om: 'Suuraa AI', en: 'Image AI' }, icon: '🎨', color: 'from-emerald-500 to-emerald-900', desc: { om: 'Image Gen', en: 'Image Gen' } },
    { mode: AppMode.VIDEO, title: { om: 'Video Premium', en: 'Video Premium' }, icon: '🎬', color: 'from-slate-700 to-black', desc: { om: 'Paid Video AI', en: 'Paid Video AI' }, premium: !isPremium },
    { mode: AppMode.GIFT, title: { om: 'Kennaa Aadaa', en: 'Cultural Gift' }, icon: '🎁', color: 'from-rose-500 to-pink-900', desc: { om: 'Exchange', en: 'Exchange' } },
    { mode: AppMode.PROFILE, title: { om: 'Profaayila Koo', en: 'My Profile' }, icon: '👤', color: 'from-slate-800 to-slate-950', desc: { om: 'Account', en: 'Account' } },
    { mode: AppMode.PAYMENT, title: { om: 'Kaffaltii', en: 'Payment' }, icon: '💳', color: 'from-blue-600 to-indigo-900', desc: { om: 'Billing', en: 'Billing' } },
    { mode: AppMode.ABOUT, title: { om: 'Dhimma Koo', en: 'About' }, icon: 'ℹ️', color: 'from-slate-400 to-slate-600', desc: { om: 'Info', en: 'Info' } },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-1000 pb-10">
      <section className="relative glass-card rounded-[3rem] p-8 sm:p-16 text-center overflow-hidden bg-white/90 border border-white shadow-2xl">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-1.5 bg-gradient-to-r from-transparent via-red-600 to-transparent"></div>
        
        <div className="relative z-10 space-y-8">
          <div className="inline-flex items-center gap-3 px-6 py-2 bg-black text-white rounded-full border border-white/20 shadow-xl">
             <span className="w-2 h-2 bg-red-500 rounded-full animate-ping"></span>
             <span className="text-[10px] font-black uppercase tracking-[0.4em]">MOHISA ORO AI</span>
          </div>
          
          <div className="space-y-2">
            <h2 className="text-5xl sm:text-7xl font-black text-slate-900 tracking-tighter italic uppercase leading-tight">
              {labels.vision}
            </h2>
            <div className="h-2 w-24 bg-red-600 mx-auto rounded-full"></div>
          </div>
          
          <p className="text-slate-500 text-sm sm:text-lg font-bold italic max-w-2xl mx-auto opacity-70 px-6 leading-relaxed">
            "{labels.description}"
          </p>

          <div className="flex flex-col items-center gap-6 pt-6">
             <div className="relative group">
                <div className={`absolute -inset-4 bg-red-600/20 rounded-[3rem] blur-2xl transition-all duration-700 opacity-0 group-hover:opacity-100 ${isAppSelected ? 'bg-emerald-600/20' : ''}`}></div>
                
                <button 
                    onClick={handleSelectApp}
                    className={`relative px-12 sm:px-20 py-7 sm:py-10 rounded-[2.8rem] font-black text-sm sm:text-lg uppercase tracking-[0.3em] shadow-2xl transition-all border-b-8 flex items-center gap-6 active:scale-95 animate-heart-beat ${
                      isAppSelected 
                      ? 'bg-emerald-600 border-emerald-900 text-white' 
                      : 'bg-red-600 border-red-800 text-white hover:bg-red-700'
                    }`}
                >
                  <span className="text-3xl sm:text-5xl">{isAppSelected ? '✅' : '⭐'}</span>
                  <span>{isAppSelected ? labels.filBtnActive : labels.filBtn}</span>
                </button>
             </div>
             
             <p className="text-[10px] sm:text-[12px] font-black text-slate-400 uppercase tracking-widest italic opacity-50 flex items-center gap-4">
               <span className="w-12 h-0.5 bg-slate-100"></span>
               {currentLanguage === Language.OROMO ? 'App koo filachuun na jajjabeessaa!' : 'Support my work by selecting my app!'}
               <span className="w-12 h-0.5 bg-slate-100"></span>
             </p>
          </div>
        </div>
      </section>

      <div className="space-y-6">
        <div className="flex items-center gap-6 px-4">
          <div className="h-px flex-1 bg-slate-100"></div>
          <h3 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.5em] italic">{labels.toolsTitle}</h3>
          <div className="h-px flex-1 bg-slate-100"></div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 px-2">
          {tools.map((tool) => (
            <button
              key={tool.mode}
              onClick={() => onNavigate(tool.mode)}
              className="group relative glass-card p-6 rounded-[2.5rem] border border-slate-100 hover:border-red-600/40 transition-all text-left flex items-center gap-6 bg-white active:scale-[0.97] shadow-lg hover:shadow-2xl"
            >
              <div className={`w-14 h-14 bg-gradient-to-br ${tool.color} rounded-2xl flex items-center justify-center text-2xl shadow-xl group-hover:rotate-12 transition-transform shrink-0 border-2 border-white/20`}>
                {tool.icon}
              </div>
              
              <div className="flex-1">
                <span className="text-[8px] font-black text-slate-300 uppercase tracking-widest block mb-1">
                  {currentLanguage === Language.OROMO ? tool.desc.om : tool.desc.en}
                </span>
                <h4 className="text-lg font-black text-slate-900 uppercase tracking-tighter group-hover:text-red-600 transition-colors flex items-center gap-2">
                  {currentLanguage === Language.OROMO ? tool.title.om : tool.title.en}
                  {tool.premium && (
                    <span className="text-[7px] font-black bg-amber-400 text-black px-2.5 py-1 rounded-full animate-pulse">
                      PREMIUM
                    </span>
                  )}
                </h4>
              </div>
              
              <div className="opacity-0 group-hover:opacity-100 transition-opacity text-slate-200 text-xl font-black">➔</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
