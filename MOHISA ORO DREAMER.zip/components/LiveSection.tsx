
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { encode, decode, decodeAudioData } from '../utils/audioUtils';
import { Language, LanguageNames, UserStats } from '../types';
import AnimatedAvatar from './AnimatedAvatar';
import { supabase } from '../supabase';
import { dbService } from '../services/dbService';

interface LiveSectionProps {
  language: Language;
  incrementStat?: (key: keyof UserStats, amount?: number) => void;
}

const LiveSection: React.FC<LiveSectionProps> = ({ language, incrementStat }) => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isModelSpeaking, setIsModelSpeaking] = useState(false);
  const [transcript, setTranscript] = useState<string>('');
  
  // Translator States
  const [isTranslatorMode, setIsTranslatorMode] = useState(true);
  const [sourceLang, setSourceLang] = useState<Language>(Language.OROMO);
  const [targetLang, setTargetLang] = useState<Language>(Language.ENGLISH);

  const audioContextInRef = useRef<AudioContext | null>(null);
  const audioContextOutRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const liveStartTimeRef = useRef<number>(0);

  const stopLive = useCallback(() => {
    if (liveStartTimeRef.current > 0) {
      const durationMin = Math.round((Date.now() - liveStartTimeRef.current) / 60000);
      if (durationMin > 0) {
        incrementStat?.('liveMinutes', durationMin);
        supabase.auth.getSession().then(({data}) => {
          if (data.session?.user) dbService.logAction(data.session.user.id, 'live_minutes', durationMin);
        });
      }
    }
    
    if (sessionRef.current) { sessionRef.current.close?.(); sessionRef.current = null; }
    if (streamRef.current) { streamRef.current.getTracks().forEach(track => track.stop()); streamRef.current = null; }
    if (scriptProcessorRef.current) { scriptProcessorRef.current.disconnect(); scriptProcessorRef.current = null; }
    if (audioContextInRef.current) { audioContextInRef.current.close(); audioContextInRef.current = null; }
    if (audioContextOutRef.current) { audioContextOutRef.current.close(); audioContextOutRef.current = null; }
    
    sourcesRef.current.forEach(s => s.stop());
    sourcesRef.current.clear();
    setIsActive(false);
    setIsConnecting(false);
    setIsModelSpeaking(false);
    liveStartTimeRef.current = 0;
  }, [incrementStat]);

  const startLive = async () => {
    if (!process.env.API_KEY) {
      setError("API Key missing. Please check your environment.");
      return;
    }

    setIsConnecting(true);
    setError(null);
    setTranscript('');

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      audioContextInRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      audioContextOutRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const langAName = LanguageNames[sourceLang];
      const langBName = LanguageNames[targetLang];

      const systemInstr = isTranslatorMode 
        ? `You are "MOHISA ORO TRANSLATOR", a high-speed bidirectional speech translator.
           ROLE: 
           1. If I speak in ${langAName}, immediately translate it to ${langBName} and speak it out.
           2. If I speak in ${langBName}, immediately translate it to ${langAName} and speak it out.
           3. Do not add conversational filler unless necessary for clarity. 
           4. Always maintain the tone and emotion of the speaker.
           5. Only output the translation as audio.`
        : `You are "MOHISA ORO", a helpful AI companion for Oromo people. Speak in Afaan Oromoo.`;

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsActive(true);
            setIsConnecting(false);
            liveStartTimeRef.current = Date.now();
            
            const source = audioContextInRef.current!.createMediaStreamSource(stream);
            const scriptProcessor = audioContextInRef.current!.createScriptProcessor(4096, 1, 1);
            scriptProcessorRef.current = scriptProcessor;
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
              const pcmData = encode(new Uint8Array(int16.buffer));
              
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: { data: pcmData, mimeType: 'audio/pcm;rate=16000' } });
              });
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContextInRef.current!.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.outputTranscription) {
              setTranscript(prev => prev + " " + message.serverContent?.outputTranscription?.text);
            }

            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio && audioContextOutRef.current) {
              setIsModelSpeaking(true);
              const ctx = audioContextOutRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const buffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = buffer;
              source.connect(ctx.destination);
              source.addEventListener('ended', () => {
                sourcesRef.current.delete(source);
                if (sourcesRef.current.size === 0) setIsModelSpeaking(false);
              });
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
            }
          },
          onerror: (e) => { 
            console.error(e); 
            setError("Network Error: Could not connect to AI services."); 
            stopLive(); 
          },
          onclose: () => stopLive(),
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
          systemInstruction: systemInstr,
          outputAudioTranscription: {},
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err) { 
      setIsConnecting(false); 
      setError("Microphone access denied or network unstable."); 
    }
  };

  const getLabels = () => {
    const translations: Record<Language, any> = {
      [Language.OROMO]: {
        title: 'HIKKAA SAGALEE',
        subtitle: 'Hiikkaa Kallattii User-to-User',
        startBtn: 'HIKKAA JALQABI',
        stopBtn: 'DHAABI',
        statusReady: 'Qophiidha, dubbadhu...',
        statusSpeaking: 'MOHISA hiikaa jira...',
        statusUser: 'Si’atu dubbachaa jira...',
        connecting: 'QUUNNAMAA JIRA...',
        modeTranslator: 'Translator Mode',
        modeChat: 'Chat Mode',
        lang1: 'Afaan Kee',
        lang2: 'Afaan Isaanii'
      },
      [Language.ENGLISH]: {
        title: 'SPEECH TRANSLATOR',
        subtitle: 'Bidirectional User-to-User Translation',
        startBtn: 'START TRANSLATING',
        stopBtn: 'STOP TRANSLATING',
        statusReady: 'Ready, speak now...',
        statusSpeaking: 'MOHISA is translating...',
        statusUser: 'You are speaking...',
        connecting: 'CONNECTING...',
        modeTranslator: 'Translator Mode',
        modeChat: 'Chat Mode',
        lang1: 'Your Language',
        lang2: 'Their Language'
      },
      [Language.TURKISH]: {
        title: 'SESLİ ÇEVİRMEN',
        subtitle: 'Çift Yönlü Kullanıcıdan Kullanıcıya Çeviri',
        startBtn: 'ÇEVİRİYİ BAŞLAT',
        stopBtn: 'ÇEVİRİYİ DURDUR',
        statusReady: 'Hazır, şimdi konuşun...',
        statusSpeaking: 'MOHISA çeviriyor...',
        statusUser: 'Siz konuşuyorsunuz...',
        connecting: 'BAĞLANILIYOR...',
        modeTranslator: 'Çevirmen Modu',
        modeChat: 'Sohbet Modu',
        lang1: 'Sizin Diliniz',
        lang2: 'Onların Dili'
      },
      [Language.SPANISH]: {
        title: 'TRADUCTOR DE VOZ',
        subtitle: 'Traducción Bidireccional Usuario a Usuario',
        startBtn: 'EMPEZAR TRADUCCIÓN',
        stopBtn: 'PARAR TRADUCCIÓN',
        statusReady: 'Listo, hable ahora...',
        statusSpeaking: 'MOHISA está traduciendo...',
        statusUser: 'Usted está hablando...',
        connecting: 'CONECTANDO...',
        modeTranslator: 'Modo Traductor',
        modeChat: 'Modo Chat',
        lang1: 'Tu Idioma',
        lang2: 'Su Idioma'
      },
    } as any;
    return translations[language] || translations[Language.ENGLISH];
  };

  const labels = getLabels();

  return (
    <div className="space-y-6 animate-in fade-in duration-700 max-w-5xl mx-auto pb-20">
      <div className="text-center space-y-1">
        <h3 className="text-3xl font-black italic uppercase tracking-tighter text-slate-900">{labels.title}</h3>
        <p className="text-slate-400 font-black text-[9px] uppercase tracking-[0.3em]">{labels.subtitle}</p>
      </div>

      <div className="glass-card rounded-[2.5rem] p-6 sm:p-10 border border-white shadow-xl bg-white/95 flex flex-col items-center">
        
        {/* Mode Toggle */}
        <div className="flex bg-slate-50 p-1 rounded-2xl mb-8 border border-slate-100 w-full max-w-xs">
          <button 
            onClick={() => !isActive && setIsTranslatorMode(true)}
            className={`flex-1 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${isTranslatorMode ? 'bg-black text-white shadow-lg' : 'text-slate-400'}`}
          >
            {labels.modeTranslator}
          </button>
          <button 
            onClick={() => !isActive && setIsTranslatorMode(false)}
            className={`flex-1 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${!isTranslatorMode ? 'bg-red-600 text-white shadow-lg' : 'text-slate-400'}`}
          >
            {labels.modeChat}
          </button>
        </div>

        {/* Translation Pair Selection */}
        {isTranslatorMode && (
          <div className="flex flex-col sm:flex-row items-center gap-4 mb-8 w-full max-w-lg">
            <div className="flex-1 w-full space-y-2">
              <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-4">{labels.lang1}</label>
              <select 
                value={sourceLang} 
                onChange={(e) => setSourceLang(e.target.value as Language)}
                disabled={isActive}
                className="w-full bg-slate-50 border border-slate-100 p-3 rounded-2xl font-bold text-xs outline-none focus:border-black transition-all"
              >
                {Object.entries(LanguageNames).map(([code, name]) => (
                  <option key={code} value={code}>{name}</option>
                ))}
              </select>
            </div>
            
            <div className="text-2xl animate-pulse hidden sm:block">↔️</div>

            <div className="flex-1 w-full space-y-2">
              <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-4">{labels.lang2}</label>
              <select 
                value={targetLang} 
                onChange={(e) => setTargetLang(e.target.value as Language)}
                disabled={isActive}
                className="w-full bg-slate-50 border border-slate-100 p-3 rounded-2xl font-bold text-xs outline-none focus:border-red-600 transition-all"
              >
                {Object.entries(LanguageNames).map(([code, name]) => (
                  <option key={code} value={code}>{name}</option>
                ))}
              </select>
            </div>
          </div>
        )}

        <div className="relative flex items-center justify-center mb-10">
           <div className={`absolute inset-0 bg-red-600/10 rounded-full blur-[60px] transition-all duration-1000 ${isActive ? 'scale-125 opacity-100' : 'scale-0 opacity-0'}`}></div>
           <AnimatedAvatar isSpeaking={isModelSpeaking} size="md" />
        </div>

        <div className="w-full space-y-6 flex flex-col items-center">
          <div className={`inline-flex items-center gap-3 px-6 py-2 rounded-full border transition-all ${isActive ? 'bg-slate-900 border-white/10 text-white' : 'bg-white border-slate-100 text-slate-300'}`}>
            <div className={`w-2 h-2 rounded-full ${isActive ? (isModelSpeaking ? 'bg-amber-400 animate-pulse' : 'bg-emerald-500 animate-ping') : 'bg-slate-100'}`}></div>
            <span className="font-black text-[9px] uppercase tracking-widest italic">
              {isActive ? (isModelSpeaking ? labels.statusSpeaking : labels.statusUser) : labels.statusReady}
            </span>
          </div>

          {!isActive ? (
            <button 
              onClick={startLive} 
              disabled={isConnecting} 
              className="px-12 py-6 bg-black text-white rounded-[2rem] font-black text-lg shadow-xl hover:scale-105 active:scale-95 transition-all border-b-6 border-slate-800 flex items-center gap-4"
            >
              {isConnecting ? "..." : (
                <>
                  <span>{labels.startBtn}</span>
                  <span className="text-2xl">🎙️</span>
                </>
              )}
            </button>
          ) : (
            <button 
              onClick={stopLive} 
              className="px-12 py-6 bg-red-600 text-white rounded-[2rem] font-black text-lg shadow-xl hover:scale-105 active:scale-95 transition-all border-b-6 border-red-900 flex items-center gap-4"
            >
              <span>{labels.stopBtn}</span>
              <span className="text-2xl">⏹️</span>
            </button>
          )}

          {transcript && (
            <div className="w-full max-w-lg p-6 bg-slate-50/50 rounded-[2rem] border border-slate-100 text-slate-800 font-bold italic text-sm shadow-inner animate-in fade-in text-center">
              "{transcript}..."
            </div>
          )}
        </div>

        {error && (
          <div className="mt-4 p-3 bg-red-50 text-red-600 rounded-xl border border-red-100 font-black text-[8px] uppercase tracking-widest">
            {error}
          </div>
        )}
      </div>
    </div>
  );
};

export default LiveSection;
