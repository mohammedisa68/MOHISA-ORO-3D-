
import React, { useState, useRef } from 'react';
import { GoogleGenAI, Modality, GenerateContentResponse } from "@google/genai";
import { decode, createWavBlob } from '../utils/audioUtils';
import { AudioData, VoiceType, Language, AppMode, UserStats } from '../types';
import AnimatedAvatar from './AnimatedAvatar';
import { dbService } from '../services/dbService';
import { supabase } from '../supabase';

interface TTSSectionProps {
  onToggleToast: (msg: string) => void;
  language: Language;
  onNavigate: (mode: AppMode) => void;
  setIsProcessing?: (val: boolean) => void;
  incrementStat?: (key: keyof UserStats, amount?: number) => void;
  initialTab?: 'TTS' | 'STT';
}

const TTSSection: React.FC<TTSSectionProps> = ({ onToggleToast, language, setIsProcessing, incrementStat, initialTab = 'TTS' }) => {
  const [activeTab, setActiveTab] = useState<'TTS' | 'STT'>(initialTab);
  const [ttsText, setTtsText] = useState('');
  const [sttText, setSttText] = useState('');
  const [selectedVoice, setSelectedVoice] = useState<VoiceType>(VoiceType.FEMALE);
  const [isAiSpeaking, setIsAiSpeaking] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [localProcessing, setLocalProcessing] = useState(false);
  const [lastGenerated, setLastGenerated] = useState<AudioData | null>(null);
  
  const currentAudioRef = useRef<HTMLAudioElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const playGeneratedAudio = (url: string) => {
    if (currentAudioRef.current) {
      currentAudioRef.current.pause();
      currentAudioRef.current.currentTime = 0;
    }
    const audio = new Audio(url);
    currentAudioRef.current = audio;
    setIsAiSpeaking(true);
    audio.play();
    audio.onended = () => setIsAiSpeaking(false);
  };

  const handleShare = async () => {
    if (!lastGenerated || !lastGenerated.blob) return;
    
    const file = new File([lastGenerated.blob], 'mohisa-voice.wav', { type: 'audio/wav' });
    const shareText = `MOHISA ORO AI Voice: "${lastGenerated.text}..."`;
    
    try {
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: 'MOHISA ORO AI Voice',
          text: shareText,
        });
      } else if (navigator.share) {
        await navigator.share({
          title: 'MOHISA ORO AI Voice',
          text: shareText,
          url: window.location.origin
        });
      } else {
        await navigator.clipboard.writeText(window.location.origin);
        onToggleToast(language === Language.OROMO ? "Linkiin garagalchameera!" : "Link copied!");
      }
      incrementStat?.('shares');
    } catch (e) { 
      console.warn("Sharing failed", e);
    }
  };

  const generateVoice = async () => {
    if (!ttsText.trim()) {
      onToggleToast(language === Language.OROMO ? "Maaloo barreeffama galchi!" : "Please enter text!");
      return;
    }
    setLocalProcessing(true);
    setIsProcessing?.(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response: GenerateContentResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Dubbiin Afaan Oromoo kanaan dubbadhu: ${ttsText}` }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: selectedVoice } } },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData)?.inlineData?.data;
      if (base64Audio) {
        const bytes = decode(base64Audio);
        const wavBlob = createWavBlob(bytes, 24000);
        const audioUrl = URL.createObjectURL(wavBlob);
        
        const newItem: AudioData = { 
          url: audioUrl, 
          timestamp: Date.now(), 
          text: ttsText.slice(0, 50), 
          blob: wavBlob 
        };
        setLastGenerated(newItem);
        playGeneratedAudio(audioUrl);
        incrementStat?.('audioCount');

        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user) {
          await dbService.saveCreation(session.user.id, 'TTS', ttsText, 'Generated_Voice');
        }
        onToggleToast(language === Language.OROMO ? "Sagaleen milkaayinaan uumameera!" : "Voice generated!");
      }
    } catch (err) { 
      onToggleToast("Network Error."); 
    } finally { 
      setLocalProcessing(false); 
      setIsProcessing?.(false);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunksRef.current.push(event.data);
      };
      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        processSTT(audioBlob);
      };
      mediaRecorder.start();
      setIsRecording(true);
      onToggleToast(language === Language.OROMO ? "Waraabaa jira..." : "Recording...");
    } catch (err) {
      onToggleToast("Microphone access denied.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  const processSTT = async (blob: Blob) => {
    setLocalProcessing(true);
    setIsProcessing?.(true);
    try {
      const reader = new FileReader();
      reader.readAsDataURL(blob);
      reader.onloadend = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: {
            parts: [
              { inlineData: { data: base64Data, mimeType: 'audio/wav' } },
              { text: "Transcribe this audio strictly in Afaan Oromo." }
            ]
          }
        });
        setSttText(response.text || '');
      };
    } catch (err) {
      onToggleToast("STT failed.");
    } finally {
      setLocalProcessing(false);
      setIsProcessing?.(false);
    }
  };

  const labels = {
    om: {
      ttsTab: 'Gara Sagaleetti',
      sttTab: 'Gara Barreeffamatti',
      genBtn: 'SAGALEE UUMI',
      recBtn: 'WARAABI',
      stopBtn: 'DHAABI',
      listen: 'DHAGGEEFFADHU',
      download: 'SAGALEE BUUFADHU',
      share: 'SAGALEE QOODADHU',
    },
    en: {
      ttsTab: 'TEXT TO SPEECH',
      sttTab: 'SPEECH TO TEXT',
      genBtn: 'GENERATE VOICE',
      recBtn: 'RECORD',
      stopBtn: 'STOP',
      listen: 'LISTEN',
      download: 'DOWNLOAD VOICE',
      share: 'SHARE VOICE',
    }
  }[language === Language.OROMO ? 'om' : 'en'];

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20 animate-in fade-in duration-1000">
      {/* Tab Switcher */}
      <div className="flex bg-white/40 backdrop-blur-3xl p-1.5 rounded-[2rem] border border-white gap-2 shadow-xl mb-4">
        <button 
          onClick={() => setActiveTab('TTS')} 
          className={`flex-1 py-4 rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'TTS' ? 'bg-black text-white shadow-lg scale-[1.02]' : 'text-slate-500 hover:text-black'}`}
        >
          {labels.ttsTab}
        </button>
        <button 
          onClick={() => setActiveTab('STT')} 
          className={`flex-1 py-4 rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'STT' ? 'bg-red-600 text-white shadow-lg scale-[1.02]' : 'text-slate-500 hover:text-black'}`}
        >
          {labels.sttTab}
        </button>
      </div>

      {/* Avatar Display */}
      <div className="flex flex-col items-center mb-8">
        <AnimatedAvatar isSpeaking={isAiSpeaking || isRecording} size="sm" />
        <div className="mt-4 flex gap-4">
           {activeTab === 'TTS' && (
             <>
               <button 
                 onClick={() => setSelectedVoice(VoiceType.FEMALE)} 
                 className={`px-6 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all border-2 ${selectedVoice === VoiceType.FEMALE ? 'bg-black text-white border-black' : 'bg-white text-slate-400 border-slate-100'}`}
               >
                 Dubartii
               </button>
               <button 
                 onClick={() => setSelectedVoice(VoiceType.MALE)} 
                 className={`px-6 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all border-2 ${selectedVoice === VoiceType.MALE ? 'bg-black text-white border-black' : 'bg-white text-slate-400 border-slate-100'}`}
               >
                 Dhiira
               </button>
             </>
           )}
        </div>
      </div>

      {/* Main Action Area */}
      <div className="glass-card rounded-[3rem] p-6 sm:p-10 border border-white shadow-2xl bg-white/95">
        {activeTab === 'TTS' ? (
          <div className="space-y-8">
            <textarea 
              value={ttsText} 
              onChange={(e) => setTtsText(e.target.value)} 
              placeholder={language === Language.OROMO ? "Barreeffama Afaan Oromoo asitti barreessi..." : "Enter Afaan Oromo text here..."} 
              className="w-full h-48 sm:h-64 p-8 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] focus:border-black outline-none text-2xl font-bold shadow-inner resize-none transition-all text-slate-900 placeholder:text-slate-200" 
            />
            
            <button 
              onClick={generateVoice} 
              disabled={localProcessing} 
              className="w-full py-8 bg-black text-white rounded-[2.5rem] font-black text-2xl shadow-2xl hover:bg-slate-900 transition-all uppercase border-b-8 border-slate-800 active:scale-95 disabled:opacity-50"
            >
              {localProcessing ? (
                <div className="flex items-center justify-center gap-4">
                  <div className="w-6 h-6 border-4 border-white/20 border-t-white rounded-full animate-spin"></div>
                  <span>QOPHEESSAA JIRA...</span>
                </div>
              ) : labels.genBtn}
            </button>

            {lastGenerated && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 animate-in slide-in-from-bottom-8 duration-700">
                <button 
                  onClick={() => playGeneratedAudio(lastGenerated.url)} 
                  className="p-6 bg-white hover:bg-slate-50 text-slate-900 rounded-[2rem] border-2 border-slate-100 flex flex-col items-center gap-4 transition-all shadow-xl group"
                >
                  <span className="text-4xl group-hover:scale-125 transition-transform">🔊</span>
                  <span className="text-[10px] font-black uppercase tracking-widest">{labels.listen}</span>
                </button>
                
                <a 
                  href={lastGenerated.url} 
                  download={`MOHISA_VOICE_${Date.now()}.wav`} 
                  className="p-6 bg-emerald-600 text-white rounded-[2rem] flex flex-col items-center gap-4 transition-all shadow-xl group border-b-8 border-emerald-800 hover:brightness-110 text-center"
                >
                  <span className="text-4xl group-hover:translate-y-1 transition-transform">📥</span>
                  <span className="text-[10px] font-black uppercase tracking-widest">{labels.download}</span>
                </a>
                
                <button 
                  onClick={handleShare} 
                  className="p-6 bg-indigo-600 text-white rounded-[2rem] flex flex-col items-center gap-4 transition-all shadow-xl group border-b-8 border-indigo-800 hover:brightness-110"
                >
                  <span className="text-4xl group-hover:rotate-12 transition-transform">📱</span>
                  <span className="text-[10px] font-black uppercase tracking-widest">{labels.share}</span>
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-8">
             <div className="relative">
                <textarea 
                  value={sttText} 
                  readOnly
                  placeholder={language === Language.OROMO ? "Barreeffama waraabame..." : "Transcribed text..."} 
                  className="w-full h-48 sm:h-64 p-8 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] outline-none text-2xl font-bold shadow-inner resize-none text-slate-900 placeholder:text-slate-200" 
                />
                {sttText && (
                  <button 
                    onClick={() => {
                      navigator.clipboard.writeText(sttText);
                      onToggleToast(language === Language.OROMO ? "Barreeffamni garagalchameera!" : "Copied to clipboard!");
                    }}
                    className="absolute top-6 right-6 p-4 bg-white rounded-2xl shadow-lg border border-slate-100 text-xl hover:scale-110 transition-all"
                  >
                    📋
                  </button>
                )}
             </div>
             
             <button 
               onClick={isRecording ? stopRecording : startRecording} 
               disabled={localProcessing} 
               className={`w-full py-10 rounded-[2.5rem] font-black text-2xl shadow-2xl transition-all uppercase flex items-center justify-center gap-8 border-b-8 active:scale-95 ${isRecording ? 'bg-red-600 text-white border-red-900 animate-pulse' : 'bg-black text-white border-slate-900'}`}
             >
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${isRecording ? 'bg-white/20' : 'bg-red-600/20'}`}>
                  <span className="text-3xl">{isRecording ? '⏹️' : '🎙️'}</span>
                </div>
                <span>{isRecording ? labels.stopBtn : labels.recBtn}</span>
             </button>
          </div>
        )}
      </div>

      <div className="text-center px-4 pt-4">
         <p className="text-[9px] font-black text-slate-300 uppercase tracking-[0.4em] italic">
           MOHISA ORO AI • Professional Afaan Oromo TTS
         </p>
      </div>
    </div>
  );
};

export default TTSSection;
