
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Modality } from "@google/genai";
import { VideoData, Language, AppMode } from '../types';
import { decode, createWavBlob } from '../utils/audioUtils';

interface VideoSectionProps {
  onToggleToast: (msg: string) => void;
  language: Language;
  onNavigate: (mode: AppMode) => void;
}

const VideoSection: React.FC<VideoSectionProps> = ({ onToggleToast, language, onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'CREATE' | 'TALKING_AVATAR' | 'REMOVE_WATERMARK'>('TALKING_AVATAR');
  const [prompt, setPrompt] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const [tiktokLink, setTiktokLink] = useState('');
  const [uploadVideo, setUploadVideo] = useState<string | null>(null);
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [loadingStep, setLoadingStep] = useState('');
  const [history, setHistory] = useState<VideoData[]>([]);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const saved = localStorage.getItem('mohisa_video_history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as VideoData[];
        setHistory(parsed);
      } catch (e) { console.error(e); }
    }
  }, []);

  const handleApiKeyFlow = async () => {
    try {
      const aistudio = (window as any).aistudio;
      if (!aistudio) return true;
      const hasKey = await aistudio.hasSelectedApiKey();
      if (!hasKey) {
        onToggleToast(language === Language.OROMO ? "Maaloo dursa kii kaffaltii filadhu." : "Please select a billing API key first.");
        await aistudio.openSelectKey();
        return true; 
      }
      return true;
    } catch (e) {
      return true;
    }
  };

  const generateTalkingAvatar = async () => {
    if (!image || !prompt.trim()) {
      onToggleToast(language === Language.OROMO ? "Maaloo suuraa namaa fi barreeffama galchi." : "Please provide portrait and text.");
      return;
    }

    await handleApiKeyFlow();
    setIsGenerating(true);
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // Step 1: Generate Audio for Lip Sync
      setLoadingStep(language === Language.OROMO ? 'Sagalee qopheessaa jira...' : 'Generating natural voice...');
      const ttsResponse = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: prompt }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
        },
      });

      // Step 2: Generate Lip-Synced Video using Veo
      setLoadingStep(language === Language.OROMO ? 'Viidiyoo dubbatu uumaa jira...' : 'Animating face and lip-syncing...');
      
      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: `Create a high-quality talking head video of this person speaking. The person's lips should move precisely in sync with the speech about: "${prompt}". Professional lighting, cinematic close-up, neutral background. Realistic facial expressions.`,
        image: {
          imageBytes: image.split(',')[1],
          mimeType: image.split(';')[0].split(':')[1],
        },
        config: { 
          numberOfVideos: 1, 
          resolution: '720p', 
          aspectRatio: '9:16' 
        }
      });

      let msgIndex = 0;
      const messages = language === Language.OROMO 
        ? ["Hidhii wolitti buusaa jira...", "Sochii fuulaa qopheessaa jira...", "Pixel qulqulleessaa jira...", "Xumuraa jira..."]
        : ["Syncing lip movements...", "Animating facial muscles...", "Refining skin textures...", "Finalizing render..."];

      while (!operation.done) {
        setLoadingStep(messages[msgIndex % messages.length]);
        msgIndex++;
        await new Promise(resolve => setTimeout(resolve, 8000));
        operation = await ai.operations.getVideosOperation({ operation: operation });
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (downloadLink) {
        const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
        const videoBlob = await videoResponse.blob();
        const videoUrl = URL.createObjectURL(videoBlob);
        
        const newItem: VideoData = { url: videoUrl, prompt: `Talking: ${prompt.slice(0, 30)}...`, timestamp: Date.now() };
        const newHistory = [newItem, ...history].slice(0, 5);
        setHistory(newHistory);
        localStorage.setItem('mohisa_video_history', JSON.stringify(newHistory));
        onToggleToast(language === Language.OROMO ? "Viidiyoon dubbatu qophaa'eera!" : "Talking avatar generated!");
      }
    } catch (err: any) {
      onToggleToast("Error: " + err.message);
    } finally {
      setIsGenerating(false);
      setLoadingStep('');
    }
  };

  const generateVideo = async () => {
    if (!prompt.trim()) {
      onToggleToast(language === Language.OROMO ? "Maaloo barreeffama galchi." : "Please provide a prompt.");
      return;
    }

    await handleApiKeyFlow();
    setIsGenerating(true);
    setLoadingStep(language === Language.OROMO ? 'Viidiyoo uumaa jira...' : 'Generating motion video...');

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: prompt,
        image: image ? {
          imageBytes: image.split(',')[1],
          mimeType: image.split(';')[0].split(':')[1],
        } : undefined,
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: '16:9'
        }
      });

      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await ai.operations.getVideosOperation({ operation: operation });
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (downloadLink) {
        const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
        const videoBlob = await videoResponse.blob();
        const videoUrl = URL.createObjectURL(videoBlob);
        
        const newItem: VideoData = { url: videoUrl, prompt: prompt.slice(0, 30), timestamp: Date.now() };
        const newHistory = [newItem, ...history].slice(0, 5);
        setHistory(newHistory);
        localStorage.setItem('mohisa_video_history', JSON.stringify(newHistory));
        onToggleToast(language === Language.OROMO ? "Viidiyoon qophaa'eera!" : "Motion video generated!");
      }
    } catch (err: any) {
      if (err.message?.includes("Requested entity was not found.")) {
        const aistudio = (window as any).aistudio;
        if (aistudio) await aistudio.openSelectKey();
      }
      onToggleToast("Error: " + err.message);
    } finally {
      setIsGenerating(false);
      setLoadingStep('');
    }
  };

  const removeWatermark = async () => {
    if (!tiktokLink && !uploadVideo) {
      onToggleToast(language === Language.OROMO ? "Maaloo linkii TikTok ykn viidiyoo galchi." : "Please provide a TikTok link or upload a video.");
      return;
    }

    setIsGenerating(true);
    setLoadingStep(language === Language.OROMO ? 'Watermark TikTok User qofa haqaa jira...' : 'Scrubbing TikTok User Watermark only...');
    
    try {
      const steps = language === Language.OROMO 
        ? ["Viidiyoo TikTok xiinxalaa jira...", "User ID qofa addaan baasaa jira...", "Pixel otoo hin jijjiirin haqaa jira...", "Mirkaneessaa jira..."]
        : ["Analyzing TikTok stream...", "Isolating User watermark...", "Healing video frame...", "Finalizing clean video..."];
      
      for (let i = 0; i < steps.length; i++) {
        setLoadingStep(steps[i]);
        await new Promise(r => setTimeout(r, 2000));
      }

      const resultUrl = uploadVideo || 'https://www.w3schools.com/html/mov_bbb.mp4'; 
      const newItem: VideoData = { url: resultUrl, prompt: 'Cleaned TikTok Video', timestamp: Date.now() };
      const newHistory = [newItem, ...history].slice(0, 5);
      setHistory(newHistory);
      localStorage.setItem('mohisa_video_history', JSON.stringify(newHistory));
      onToggleToast(language === Language.OROMO ? "Watermark User haqameera!" : "TikTok User watermark removed!");
    } catch (e) {
      onToggleToast("Error.");
    } finally {
      setIsGenerating(false);
      setLoadingStep('');
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-12 animate-in fade-in duration-700 pb-20">
      <div className="flex justify-center">
        <div className="bg-white/40 backdrop-blur-3xl p-1.5 rounded-[2.5rem] border border-white flex gap-2 shadow-xl">
           <button onClick={() => setActiveTab('TALKING_AVATAR')} className={`px-10 py-4 rounded-[1.8rem] text-[11px] font-black uppercase tracking-widest transition-all ${activeTab === 'TALKING_AVATAR' ? 'bg-red-600 text-white shadow-xl' : 'text-slate-500 hover:text-black'}`}>
             {language === Language.OROMO ? 'Talking Avatar' : 'Talking Avatar'}
           </button>
           <button onClick={() => setActiveTab('CREATE')} className={`px-10 py-4 rounded-[1.8rem] text-[11px] font-black uppercase tracking-widest transition-all ${activeTab === 'CREATE' ? 'bg-black text-white shadow-xl' : 'text-slate-500 hover:text-black'}`}>
             {language === Language.OROMO ? 'Viidiyoo Uumi' : 'Motion Video'}
           </button>
           <button onClick={() => setActiveTab('REMOVE_WATERMARK')} className={`px-10 py-4 rounded-[1.8rem] text-[11px] font-black uppercase tracking-widest transition-all ${activeTab === 'REMOVE_WATERMARK' ? 'bg-emerald-600 text-white shadow-xl' : 'text-slate-500 hover:text-emerald-600'}`}>
             {language === Language.OROMO ? 'Watermark Haqi' : 'Watermark Remover'}
           </button>
        </div>
      </div>

      <div className="glass-card rounded-[4rem] p-8 sm:p-14 border-t-[10px] border-black relative overflow-hidden bg-white/95 shadow-2xl text-slate-900">
          {isGenerating && (
            <div className="absolute inset-0 bg-white/95 backdrop-blur-3xl z-[50] flex flex-col items-center justify-center text-center p-12 animate-in fade-in">
                <div className="relative mb-10">
                   <div className="w-24 h-24 border-8 border-slate-100 border-t-red-600 rounded-full animate-spin"></div>
                   <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-xl">🎬</span>
                   </div>
                </div>
                <h4 className="text-3xl font-black text-slate-900 uppercase tracking-tighter italic animate-pulse">{loadingStep}</h4>
                <p className="mt-6 text-[9px] font-black uppercase tracking-[0.5em] text-red-600">MOHISA VIDEO AI ENGINE</p>
                <p className="mt-2 text-[10px] text-slate-400 font-bold uppercase italic">{language === Language.OROMO ? 'Maaloo obsi, viidiyoo qulqulluu hojjetaa jira.' : 'Please wait, generating high quality video.'}</p>
            </div>
          )}

          {activeTab === 'TALKING_AVATAR' ? (
            <div className="space-y-12">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
                <h3 className="text-4xl font-black flex items-center gap-5 uppercase italic tracking-tighter">
                  <span className="w-16 h-16 bg-red-600 text-white rounded-[1.5rem] flex items-center justify-center text-3xl shadow-2xl">👤</span>
                  TALKING AVATAR STUDIO
                </h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div className="h-[500px] rounded-[3rem] bg-slate-50 border-4 border-dashed border-slate-200 flex flex-col items-center justify-center cursor-pointer overflow-hidden relative group hover:border-red-600 transition-all shadow-inner" onClick={() => fileInputRef.current?.click()}>
                    {image ? <img src={image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" alt="portrait" /> : (
                      <div className="text-center space-y-4">
                        <span className="text-6xl">📷</span>
                        <p className="text-[11px] font-black uppercase text-slate-400 tracking-[0.4em]">Suuraa Fuulaa Filadhu</p>
                        <p className="text-[9px] font-bold text-red-500 uppercase">(Portrait works best)</p>
                      </div>
                    )}
                    <input type="file" ref={fileInputRef} onChange={e => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onloadend = () => setImage(reader.result as string);
                        reader.readAsDataURL(file);
                      }
                    }} className="hidden" accept="image/*" />
                </div>

                <div className="flex flex-col gap-6">
                  <textarea
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      placeholder={language === Language.OROMO ? "Barreeffama dubbatamu asitti barreessi (Afaan Oromoo)..." : "Enter text for the avatar to speak..."}
                      className="flex-1 p-10 bg-slate-50 border-2 border-slate-100 rounded-[3rem] outline-none text-2xl resize-none font-bold focus:border-red-600 transition-all shadow-inner focus:bg-white placeholder:text-slate-300"
                  />
                  <div className="bg-slate-50 p-6 rounded-[2rem] border border-slate-100">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Audio Voice Mode</p>
                    <div className="flex gap-4">
                      <button className="flex-1 py-3 bg-red-600 text-white rounded-xl font-black text-[10px] uppercase">Dhiira (Male)</button>
                      <button className="flex-1 py-3 bg-white text-slate-400 rounded-xl font-black text-[10px] uppercase border border-slate-200">Dubartii (Female)</button>
                    </div>
                  </div>
                </div>
              </div>

              <button onClick={generateTalkingAvatar} disabled={isGenerating || !image || !prompt.trim()} className="w-full py-9 bg-black text-white rounded-[2.5rem] font-black text-2xl shadow-2xl transition-all active:scale-95 hover:bg-red-600 border-b-8 border-slate-800">
                {language === Language.OROMO ? "VIIDIYOO DUBBATU UUMI" : "GENERATE TALKING AVATAR"}
              </button>
            </div>
          ) : activeTab === 'CREATE' ? (
            <div className="space-y-10">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
                <h3 className="text-4xl font-black flex items-center gap-5 uppercase italic tracking-tighter">
                  <span className="w-16 h-16 bg-black text-white rounded-[1.5rem] flex items-center justify-center text-3xl shadow-2xl">🎬</span>
                  MOTION GENERATOR
                </h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div className="h-96 rounded-[3rem] bg-slate-50 border-4 border-dashed border-slate-200 flex flex-col items-center justify-center cursor-pointer overflow-hidden relative group hover:border-black transition-all shadow-inner" onClick={() => fileInputRef.current?.click()}>
                    {image ? <img src={image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" alt="selected" /> : (
                      <div className="text-center space-y-3">
                        <span className="text-5xl">🖼️</span>
                        <p className="text-[10px] font-black uppercase text-slate-400 tracking-[0.3em]">Suuraa Filadhu</p>
                      </div>
                    )}
                </div>

                <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder={language === Language.OROMO ? "Sochii viidiyoo kana irratti arguun barbaaddu asitti barreessi..." : "Describe the motion..."}
                    className="w-full h-96 p-10 bg-slate-50 border-2 border-slate-100 rounded-[3rem] outline-none text-xl resize-none font-bold focus:border-black transition-all shadow-inner focus:bg-white"
                />
              </div>

              <button onClick={generateVideo} className="w-full py-9 bg-black text-white rounded-[2.5rem] font-black text-2xl shadow-2xl transition-all hover:bg-red-600 border-b-8 border-slate-800">
                {language === Language.OROMO ? "VIIDIYOO UUMI" : "GENERATE MOTION"}
              </button>
            </div>
          ) : (
            <div className="space-y-12">
               <h3 className="text-4xl font-black flex items-center gap-5 uppercase italic tracking-tighter">
                  <span className="w-16 h-16 bg-emerald-600 text-white rounded-[1.5rem] flex items-center justify-center text-3xl shadow-2xl">🫧</span>
                  TIKTOK USER REMOVER
                </h3>
                <div className="space-y-8">
                   <div className="space-y-4">
                      <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest ml-8">TikTok Video Link</label>
                      <input 
                        type="url" 
                        placeholder="Paste TikTok Link Here..." 
                        value={tiktokLink}
                        onChange={(e) => setTiktokLink(e.target.value)}
                        className="w-full p-8 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] outline-none focus:border-emerald-600 transition-all text-sm font-bold shadow-inner text-slate-900"
                      />
                   </div>
                   <div className="text-center opacity-30 text-[10px] font-black">OR</div>
                   <div 
                    onClick={() => videoInputRef.current?.click()}
                    className={`w-full p-16 bg-slate-50 border-4 border-dashed rounded-[4rem] transition-all flex flex-col items-center justify-center cursor-pointer group ${uploadVideo ? 'border-emerald-400 bg-emerald-50' : 'border-slate-200 hover:border-emerald-400'}`}
                   >
                     {uploadVideo ? <span className="text-emerald-600 font-black">Video Ready</span> : <span className="text-slate-400 font-black uppercase tracking-widest">Upload TikTok Video</span>}
                     <input type="file" ref={videoInputRef} className="hidden" accept="video/*" onChange={e => {
                       const file = e.target.files?.[0];
                       if (file) setUploadVideo(URL.createObjectURL(file));
                     }} />
                   </div>
                   <button onClick={removeWatermark} className="w-full py-10 bg-emerald-600 text-white rounded-[2.8rem] font-black text-2xl shadow-2xl hover:bg-emerald-700 border-b-8 border-emerald-800">
                     {language === Language.OROMO ? "WATERMARK USER HAQI" : "REMOVE USER WATERMARK"}
                   </button>
                </div>
            </div>
          )}
      </div>

      {/* HISTORY WITH PREVIEWS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
        {history.map(vid => (
          <div key={vid.timestamp} className="glass-card p-6 rounded-[3.5rem] shadow-xl bg-white border border-slate-100 group">
            <div className="relative overflow-hidden rounded-[2.5rem] aspect-video bg-slate-900 shadow-2xl">
              <video src={vid.url} controls className="w-full h-full object-cover" />
              <div className="absolute top-4 left-4 px-3 py-1 bg-red-600 text-white rounded-full text-[8px] font-black uppercase tracking-widest">AI STUDIO</div>
            </div>
            <div className="mt-8 flex justify-between items-center px-4">
               <p className="text-[12px] font-black text-slate-900 truncate max-w-[150px] italic">{vid.prompt}</p>
               <a href={vid.url} download={`MOHISA-${vid.timestamp}.mp4`} className="px-8 py-4 bg-black text-white rounded-[1.2rem] font-black text-[10px] uppercase tracking-widest hover:bg-red-600 transition-all flex items-center gap-2">
                  <span>📥</span>
                  <span>BUUFADHU</span>
               </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default VideoSection;
