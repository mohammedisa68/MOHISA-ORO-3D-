
import React from 'react';
import { AppMode, Language } from '../types';

interface NavControlsProps {
  currentMode: AppMode;
  onModeChange: (mode: AppMode) => void;
  language: Language;
}

const NavControls: React.FC<NavControlsProps> = ({ currentMode, onModeChange, language }) => {
  const modes = Object.values(AppMode);
  const currentIndex = modes.indexOf(currentMode);

  const handleNext = () => {
    const nextIndex = (currentIndex + 1) % modes.length;
    onModeChange(modes[nextIndex]);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBack = () => {
    const prevIndex = (currentIndex - 1 + modes.length) % modes.length;
    onModeChange(modes[prevIndex]);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const t = {
    om: { next: 'ITTI FUFI', back: 'DUUBATTI' },
    en: { next: 'NEXT', back: 'BACK' }
  }[language === Language.OROMO ? 'om' : 'en'];

  return (
    <div className="w-full flex items-center justify-between gap-4 py-4 px-2 animate-in fade-in duration-700 max-w-lg mx-auto">
      
      {/* SMALL COMPACT BACK BUTTON - COMBO STYLE */}
      <button
        onClick={handleBack}
        className="flex-1 flex items-center justify-center gap-2 bg-black/90 text-white px-4 py-3 rounded-xl shadow-lg hover:bg-slate-800 active:translate-y-0.5 transition-all border-b-4 border-slate-900 group"
      >
        <span className="text-sm group-hover:-translate-x-1 transition-transform">⬅️</span>
        <span className="font-black text-[8px] sm:text-[10px] uppercase tracking-widest">{t.back}</span>
      </button>

      {/* MINI INDICATORS */}
      <div className="hidden sm:flex gap-1.5">
         {modes.slice(0, 5).map((_, i) => (
           <div 
            key={i} 
            className={`h-1 rounded-full transition-all duration-500 ${currentIndex % 5 === i ? 'w-4 bg-red-600' : 'w-1 bg-slate-200'}`}
           ></div>
         ))}
      </div>

      {/* SMALL COMPACT NEXT BUTTON - COMBO STYLE */}
      <button
        onClick={handleNext}
        className="flex-1 flex items-center justify-center gap-2 bg-red-600 text-white px-4 py-3 rounded-xl shadow-lg hover:bg-red-700 active:translate-y-0.5 transition-all border-b-4 border-red-900 group"
      >
        <span className="font-black text-[8px] sm:text-[10px] uppercase tracking-widest">{t.next}</span>
        <span className="text-sm group-hover:translate-x-1 transition-transform">➡️</span>
      </button>
      
    </div>
  );
};

export default NavControls;
