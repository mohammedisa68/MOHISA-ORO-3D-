
import React, { useEffect, useState } from 'react';
import { supabase } from '../supabase';
import { Language, UserStats } from '../types';

interface ProfileSectionProps {
  language: Language;
}

const ProfileSection: React.FC<ProfileSectionProps> = ({ language }) => {
  const [user, setUser] = useState<any>(null);
  const [stats, setStats] = useState<UserStats>({ audioCount: 0, imageCount: 0, videoCount: 0, giftPoints: 0 });
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'ACTIVITY' | 'SETTINGS'>('OVERVIEW');

  useEffect(() => {
    const fetchUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user ?? null);
    };
    fetchUser();

    // Fetch stats from local storage or placeholder for now
    const savedStats = JSON.parse(localStorage.getItem('mohisa_stats') || '{"audioCount":12,"imageCount":8,"videoCount":3,"giftPoints":450}');
    setStats(savedStats);
  }, []);

  if (!user) return (
    <div className="flex flex-col items-center justify-center p-20 animate-pulse">
      <div className="w-16 h-16 border-4 border-red-600 border-t-transparent rounded-full animate-spin mb-4"></div>
      <p className="text-slate-400 font-black uppercase tracking-widest text-[10px]">Odeeffannoo fidaa jira...</p>
    </div>
  );

  const t = {
    om: { 
      title: 'PROFAAYILA KOO', 
      stats: 'Istatistikii', 
      logout: 'Gadi Ba',
      member: 'MOHISA PRO',
      overview: 'Xumura',
      activity: 'Sochii',
      settings: 'Sajoo',
      since: 'Tajaajilarratti:',
      updateBtn: 'Account Haaromsi',
      accType: 'Gosa Account:'
    },
    en: { 
      title: 'MY PROFILE', 
      stats: 'User Statistics', 
      logout: 'Logout',
      member: 'PRO MEMBER',
      overview: 'Overview',
      activity: 'Activity',
      settings: 'Settings',
      since: 'Member since:',
      updateBtn: 'Update Account',
      accType: 'Account Type:'
    }
  }[language === Language.OROMO ? 'om' : 'en'];

  return (
    <div className="max-w-5xl mx-auto space-y-12 animate-in fade-in slide-in-from-bottom-10 duration-700 pb-20">
      
      {/* PREMIUM PROFILE HEADER */}
      <div className="glass-card rounded-[4rem] p-10 sm:p-20 border-t-[16px] border-t-red-600 shadow-2xl relative overflow-hidden bg-white/95 ring-1 ring-black/5">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-red-600/5 rounded-full -mr-48 -mt-48 blur-[120px] pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-black/5 rounded-full -ml-32 -mb-32 blur-[80px] pointer-events-none"></div>
        
        <div className="flex flex-col md:flex-row items-center gap-12 relative z-10">
          <div className="relative group">
            <div className="w-44 h-44 sm:w-60 sm:h-60 bg-slate-900 text-white rounded-[3.5rem] flex items-center justify-center text-8xl font-black shadow-2xl border-8 border-white rotate-3 transition-all group-hover:rotate-0 duration-500 group-hover:scale-105">
              {user.user_metadata?.full_name?.[0] || user.email?.[0].toUpperCase() || 'M'}
            </div>
            <div className="absolute -bottom-4 -right-4 bg-gradient-to-br from-red-600 to-black text-white px-8 py-3 rounded-full text-[10px] font-black uppercase tracking-[0.2em] shadow-2xl border-4 border-white animate-bounce">
              {t.member}
            </div>
          </div>
          
          <div className="flex-1 text-center md:text-left space-y-5">
            <div className="space-y-2">
              <h2 className="text-5xl sm:text-7xl font-black tracking-tighter uppercase italic leading-none text-slate-900">
                {user.user_metadata?.full_name || 'Mohisa User'}
              </h2>
              <p className="text-slate-400 font-bold text-sm uppercase tracking-[0.4em] flex items-center justify-center md:justify-start gap-2">
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                {user.email}
              </p>
            </div>
            
            <div className="flex flex-wrap justify-center md:justify-start gap-4">
              <div className="px-6 py-2 bg-slate-100 rounded-full text-[9px] font-black uppercase tracking-widest text-slate-500 border border-slate-200">
                {t.accType} PREMIUM
              </div>
              <div className="px-6 py-2 bg-red-50 text-red-600 rounded-full text-[9px] font-black uppercase tracking-widest border border-red-100">
                VERIFIED ✓
              </div>
            </div>

            <p className="text-slate-500 font-black text-[10px] uppercase tracking-widest flex items-center justify-center md:justify-start gap-3 opacity-60">
              <span className="w-10 h-0.5 bg-slate-300"></span>
              {t.since} {new Date(user.created_at).toLocaleDateString()}
            </p>
          </div>

          <button 
            onClick={() => supabase.auth.signOut()}
            className="px-12 py-6 bg-slate-900 text-white rounded-full font-black text-xs uppercase tracking-[0.3em] shadow-2xl hover:bg-red-600 transition-all active:scale-95 group flex items-center gap-4"
          >
            <span>{t.logout}</span>
            <span className="text-xl group-hover:translate-x-1 transition-transform">➔</span>
          </button>
        </div>
      </div>

      {/* NAVIGATION TABS */}
      <div className="flex bg-white/60 backdrop-blur-3xl p-2.5 rounded-[2.5rem] border border-white max-w-2xl mx-auto shadow-2xl ring-1 ring-black/5">
        {[
          { id: 'OVERVIEW', label: t.overview, icon: '📊' },
          { id: 'ACTIVITY', label: t.activity, icon: '⚡' },
          { id: 'SETTINGS', label: t.settings, icon: '⚙️' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex-1 py-4.5 px-6 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-3 ${activeTab === tab.id ? 'bg-black text-white shadow-2xl scale-[1.03] z-10' : 'text-slate-400 hover:text-slate-900 hover:bg-white/50'}`}
          >
            <span className="text-xl">{tab.icon}</span>
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* DYNAMIC CONTENT AREA */}
      <div className="min-h-[500px] relative">
        {activeTab === 'OVERVIEW' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 animate-in fade-in slide-in-from-top-4 duration-500">
            {[
              { label: language === Language.OROMO ? 'Sagalee Uumame' : 'Audios Created', value: stats.audioCount, color: 'text-red-600', icon: '🎙️' },
              { label: language === Language.OROMO ? 'Suuraa Uumame' : 'Images Generated', value: stats.imageCount, color: 'text-emerald-600', icon: '🎨' },
              { label: language === Language.OROMO ? 'Viidiyoo Uumame' : 'Videos Made', value: stats.videoCount, color: 'text-blue-600', icon: '🎬' },
              { label: language === Language.OROMO ? 'Qabxii Mohisa' : 'Mohisa Points', value: stats.giftPoints, color: 'text-amber-500', icon: '💎' }
            ].map((s, i) => (
              <div key={i} className="p-10 rounded-[3.5rem] border border-slate-100 flex flex-col items-center text-center shadow-xl transition-all hover:scale-105 bg-white group hover:border-red-600/20">
                <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-3xl mb-6 shadow-inner group-hover:rotate-12 transition-transform">{s.icon}</div>
                <span className={`text-6xl font-black ${s.color} mb-3 tracking-tighter italic`}>{s.value}</span>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-relaxed px-4">{s.label}</span>
                <div className={`w-12 h-1.5 rounded-full mt-8 ${s.color.replace('text', 'bg')} opacity-20`}></div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'ACTIVITY' && (
          <div className="glass-card rounded-[3.5rem] p-12 bg-white/90 animate-in fade-in slide-in-from-top-6 duration-500 space-y-10 shadow-2xl border border-white">
            <div className="flex justify-between items-center px-4">
              <h4 className="text-3xl font-black uppercase tracking-tighter italic text-slate-900">Recent Activity</h4>
              <button className="text-[10px] font-black text-red-600 uppercase tracking-widest hover:underline">Clear All</button>
            </div>
            <div className="space-y-6">
              {[
                { action: 'Created Voice', time: '2 hours ago', icon: '🔊', status: 'COMPLETED' },
                { action: 'Generated Image', time: '5 hours ago', icon: '🎨', status: 'SAVED' },
                { action: 'Gift Swap Success', time: 'Yesterday', icon: '🎁', status: 'SUCCESS' }
              ].map((act, i) => (
                <div key={i} className="flex items-center gap-8 p-8 bg-slate-50/50 rounded-[2.5rem] border border-slate-100 group hover:bg-white transition-all hover:shadow-xl">
                  <div className="w-20 h-20 bg-black text-white rounded-3xl flex items-center justify-center text-3xl shadow-2xl group-hover:rotate-6 transition-transform">{act.icon}</div>
                  <div className="flex-1">
                    <p className="font-black text-xl text-slate-900 uppercase tracking-tight">{act.action}</p>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">{act.time} • Sync</p>
                  </div>
                  <div className="text-emerald-600 font-black text-xs bg-emerald-50 px-6 py-2 rounded-full border border-emerald-100 group-hover:bg-emerald-600 group-hover:text-white transition-all">
                    {act.status}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'SETTINGS' && (
          <div className="glass-card rounded-[3.5rem] p-12 bg-white/90 animate-in fade-in slide-in-from-top-6 duration-500 space-y-12 shadow-2xl border border-white">
            <h4 className="text-3xl font-black uppercase tracking-tighter italic text-slate-900 px-4">Account Settings</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="space-y-4">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-6">Full Name (Maqaa)</label>
                <input type="text" value={user.user_metadata?.full_name} readOnly className="w-full p-8 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-slate-900 outline-none shadow-inner text-xl" />
              </div>
              <div className="space-y-4">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-6">Email Address</label>
                <input type="text" value={user.email} readOnly className="w-full p-8 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-slate-900 outline-none shadow-inner text-xl" />
              </div>
              <div className="space-y-4">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-6">Phone (Optional)</label>
                <input type="text" placeholder="+251..." className="w-full p-8 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-slate-900 outline-none focus:border-red-600 transition-all text-xl" />
              </div>
              <div className="space-y-4">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-6">Regional Language</label>
                <div className="w-full p-8 bg-slate-50 border-2 border-slate-100 rounded-[2rem] font-black text-slate-900 shadow-inner text-xl">
                  {language === Language.OROMO ? 'Afaan Oromoo' : 'English'}
                </div>
              </div>
            </div>
            <div className="flex justify-end pt-6">
              <button className="px-16 py-7 bg-black text-white rounded-full font-black text-[12px] uppercase tracking-[0.3em] shadow-2xl hover:bg-red-600 transition-all active:scale-95">
                {t.updateBtn}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* FOOTER DECORATION */}
      <div className="text-center opacity-30 hover:opacity-100 transition-opacity duration-700 py-10">
        <p className="text-[12px] font-black uppercase tracking-[1em] text-slate-900 mb-4">MOHISA ORO • SECURE VAULT</p>
        <div className="h-1.5 w-48 bg-gradient-to-r from-transparent via-red-600 to-transparent mx-auto rounded-full"></div>
      </div>
    </div>
  );
};

export default ProfileSection;
