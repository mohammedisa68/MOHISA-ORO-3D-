
import React, { useState } from 'react';
import { Language } from '../types';

interface PaymentSectionProps {
  onToggleToast: (msg: string) => void;
  language: Language;
  onPaymentSuccess: () => void;
}

type PaymentMethod = 'TELEBIRR' | 'MASTERCARD' | 'PAYPAL' | 'COIN';

const PaymentSection: React.FC<PaymentSectionProps> = ({ onToggleToast, language, onPaymentSuccess }) => {
  const [method, setMethod] = useState<PaymentMethod>('TELEBIRR');
  const [phone, setPhone] = useState('');
  const [paypalEmail, setPaypalEmail] = useState('');
  const [cardDetails, setCardDetails] = useState({ number: '', expiry: '', cvv: '' });
  const [selectedPlan, setSelectedPlan] = useState<number | null>(null);
  const [step, setStep] = useState<'IDLE' | 'PROCESSING' | 'CONFIRMING' | 'SUCCESS'>('IDLE');

  const plans = [
    { id: 1, name: { om: 'Guyyaa 1', en: '1 Day', ar: 'يوم واحد' }, price: '5 ETB', desc: { om: 'Hanga dhumatti fayyadamaa', en: 'Unlimited for 24h', ar: 'غير محدود لمدة ٢٤ ساعة' } },
    { id: 2, name: { om: 'Torban 1', en: '1 Week', ar: 'أسبوع واحد' }, price: '25 ETB', desc: { om: 'Saffisa ol-aanaa', en: 'High speed access', ar: 'وصول عالي السرعة' } },
    { id: 3, name: { om: 'Ji' + "'" + 'a 1', en: '1 Month', ar: 'شهر واحد' }, price: '80 ETB', desc: { om: 'Gatii gadi bu' + "'" + 'aa', en: 'Best value plan', ar: 'أفضل قيمة' } },
  ];

  const handlePay = () => {
    if (selectedPlan === null) {
      onToggleToast(language === Language.OROMO ? "Maaloo dura karoora filadhu!" : "Please select a plan first!");
      return;
    }

    if (method === 'TELEBIRR' && (!phone.startsWith('09') && !phone.startsWith('07'))) {
      onToggleToast(language === Language.OROMO ? "Lakkofsa bilbilaa Telebirr sirrii galchi!" : "Enter valid Telebirr phone number!");
      return;
    }

    if (method === 'MASTERCARD' && cardDetails.number.length < 16) {
      onToggleToast(language === Language.OROMO ? "Lakkofsa Kaardii sirrii galchi!" : "Enter valid Card number!");
      return;
    }

    if (method === 'PAYPAL' && (!paypalEmail.includes('@') || !paypalEmail.includes('.'))) {
      onToggleToast(language === Language.OROMO ? "Email PayPal sirrii galchi!" : "Enter a valid PayPal email!");
      return;
    }

    setStep('PROCESSING');
    setTimeout(() => {
      setStep('CONFIRMING');
      setTimeout(() => {
        setStep('SUCCESS');
        onPaymentSuccess();
        onToggleToast(language === Language.OROMO ? "Kaffaltiin keessan milkaa'inaan xumurameera!" : "Your payment has been completed successfully!");
      }, 3000);
    }, 2000);
  };

  if (step === 'SUCCESS') {
    return (
      <div className="max-w-2xl mx-auto glass-card rounded-[3.5rem] p-12 text-center animate-in zoom-in-95">
        <div className="w-24 h-24 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-8 text-4xl shadow-inner">✓</div>
        <h2 className="text-3xl font-black mb-4">{language === Language.OROMO ? "Kaffaltiin Milkaa'eera!" : "Payment Successful!"}</h2>
        <p className="text-slate-500 font-medium mb-10">
          {language === Language.OROMO 
            ? "Kaffaltiin keessan mirkanaa'eera. Amma tajaajila MOHISA ORO hunda fayyadamuu dandeessu." 
            : "Your payment has been confirmed. You now have full access to all MOHISA ORO services."}
        </p>
        <button onClick={() => window.location.reload()} className="w-full py-5 bg-black text-white rounded-2xl font-black uppercase tracking-widest">Gara Jalqabaatti Deebi'i</button>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-12 pb-20 animate-in fade-in slide-in-from-bottom-10 duration-700">
      <div className="glass-card rounded-[4rem] p-8 sm:p-16 border border-white shadow-2xl relative overflow-hidden bg-white/95">
        
        {/* PROGRESS OVERLAY */}
        {step !== 'IDLE' && (
          <div className="absolute inset-0 bg-white/95 backdrop-blur-md z-[100] flex flex-col items-center justify-center p-12 text-center">
            <div className="relative mb-8">
               <div className="w-20 h-20 border-4 border-slate-100 border-t-red-600 rounded-full animate-spin"></div>
               <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-xs font-black">AI</span>
               </div>
            </div>
            <h3 className="text-3xl font-black text-slate-900 mb-2 tracking-tighter uppercase italic">
              {step === 'PROCESSING' 
                ? (language === Language.OROMO ? "Baankii waliin wal-qunnamaa jira..." : "Connecting to bank...") 
                : (language === Language.OROMO ? "Kaffaltii mirkaneessaa jira..." : "Verifying transaction...")}
            </h3>
            <p className="text-slate-400 font-black uppercase tracking-[0.4em] text-[10px]">MOHISA ORO SECURE CHECKOUT v5.0</p>
          </div>
        )}

        <div className="flex flex-col gap-10 mb-16">
            <div className="text-center space-y-2">
               <h2 className="text-5xl font-black tracking-tighter italic uppercase">{language === Language.OROMO ? 'Karaa Kaffaltii' : 'Payment Gateways'}</h2>
               <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.5em]">Secure & Encrypted</p>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-4 bg-slate-50 p-2 rounded-[2.5rem] gap-2 border border-slate-100">
                {(['TELEBIRR', 'MASTERCARD', 'PAYPAL', 'COIN'] as PaymentMethod[]).map(m => (
                    <button 
                        key={m} 
                        onClick={() => setMethod(m)}
                        className={`py-5 rounded-[1.8rem] font-black text-[10px] uppercase tracking-widest transition-all flex flex-col items-center gap-2 ${method === m ? 'bg-black text-white shadow-2xl scale-[1.05] z-10' : 'text-slate-400 hover:text-slate-900 hover:bg-white/50'}`}
                    >
                        <span className="text-xl">
                          {m === 'TELEBIRR' ? '📱' : m === 'MASTERCARD' ? '💳' : m === 'PAYPAL' ? '🅿️' : '🪙'}
                        </span>
                        <span>{m}</span>
                    </button>
                ))}
            </div>
        </div>

        {/* PLAN SELECTION */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 mb-16">
          {plans.map(plan => (
            <button
              key={plan.id}
              onClick={() => setSelectedPlan(plan.id)}
              className={`p-10 rounded-[3rem] border-4 transition-all text-left flex flex-col gap-6 relative group ${
                selectedPlan === plan.id 
                ? 'bg-black border-black text-white shadow-2xl scale-[1.02]' 
                : 'bg-white border-slate-50 hover:border-slate-200 shadow-sm'
              }`}
            >
              <div className="flex justify-between items-start">
                 <span className={`text-[10px] font-black uppercase tracking-[0.3em] ${selectedPlan === plan.id ? 'text-red-500' : 'text-slate-300'}`}>
                    {plan.name[language]}
                 </span>
                 {selectedPlan === plan.id && <span className="text-xl">💎</span>}
              </div>
              <div>
                 <span className="text-4xl font-black tracking-tighter block mb-1">{plan.price}</span>
                 <p className={`text-[11px] font-bold leading-relaxed uppercase tracking-wider ${selectedPlan === plan.id ? 'text-slate-400' : 'text-slate-500'}`}>
                    {plan.desc[language]}
                 </p>
              </div>
              <div className={`h-1.5 w-12 rounded-full ${selectedPlan === plan.id ? 'bg-red-600' : 'bg-slate-100'}`}></div>
            </button>
          ))}
        </div>

        {/* METHOD SPECIFIC INPUTS */}
        <div className="space-y-8 bg-slate-50/50 p-10 rounded-[3.5rem] border border-slate-100">
          {method === 'TELEBIRR' && (
            <div className="space-y-4 animate-in slide-in-from-top-4">
                <div className="flex items-center gap-4 mb-4">
                   <div className="w-12 h-12 bg-black text-white rounded-xl flex items-center justify-center font-black italic text-xl shadow-lg">tb</div>
                   <h4 className="font-black text-sm uppercase tracking-widest text-slate-900">Telebirr Checkout</h4>
                </div>
                <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Lakkofsa Bilbilaa</label>
                    <input 
                        type="tel"
                        placeholder="09... / 07..."
                        value={phone}
                        onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                        className="w-full p-8 bg-white border-2 border-slate-200 rounded-[2.5rem] outline-none focus:border-red-600 transition-all text-3xl font-black tracking-widest shadow-inner"
                    />
                </div>
            </div>
          )}

          {method === 'MASTERCARD' && (
            <div className="space-y-6 animate-in slide-in-from-top-4">
                <div className="flex items-center gap-4 mb-4">
                   <div className="w-12 h-12 bg-red-600 text-white rounded-xl flex items-center justify-center text-xl shadow-lg">MC</div>
                   <h4 className="font-black text-sm uppercase tracking-widest text-slate-900">Mastercard / Visa</h4>
                </div>
                <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Card Number</label>
                    <input 
                        type="text"
                        placeholder="XXXX XXXX XXXX XXXX"
                        value={cardDetails.number}
                        onChange={(e) => setCardDetails({...cardDetails, number: e.target.value.replace(/\D/g, '').slice(0, 16)})}
                        className="w-full p-8 bg-white border-2 border-slate-200 rounded-[2.5rem] outline-none focus:border-red-600 transition-all text-2xl font-black tracking-[0.2em] shadow-inner"
                    />
                </div>
                <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">Expiry Date</label>
                       <input 
                           placeholder="MM/YY"
                           value={cardDetails.expiry}
                           onChange={(e) => setCardDetails({...cardDetails, expiry: e.target.value})}
                           className="w-full p-8 bg-white border-2 border-slate-200 rounded-[2.5rem] outline-none text-xl font-black shadow-inner"
                       />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">CVV Code</label>
                       <input 
                           placeholder="***"
                           type="password"
                           maxLength={3}
                           value={cardDetails.cvv}
                           onChange={(e) => setCardDetails({...cardDetails, cvv: e.target.value})}
                           className="w-full p-8 bg-white border-2 border-slate-200 rounded-[2.5rem] outline-none text-xl font-black shadow-inner"
                       />
                    </div>
                </div>
            </div>
          )}

          {method === 'PAYPAL' && (
            <div className="space-y-4 animate-in slide-in-from-top-4">
                <div className="flex items-center gap-4 mb-4">
                   <div className="w-12 h-12 bg-blue-600 text-white rounded-xl flex items-center justify-center font-black text-xl shadow-lg">P</div>
                   <h4 className="font-black text-sm uppercase tracking-widest text-slate-900">PayPal Global</h4>
                </div>
                <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-6">PayPal Email Address</label>
                    <input 
                        type="email"
                        placeholder="example@paypal.com"
                        value={paypalEmail}
                        onChange={(e) => setPaypalEmail(e.target.value)}
                        className="w-full p-8 bg-white border-2 border-slate-200 rounded-[2.5rem] outline-none focus:border-blue-600 transition-all text-2xl font-black shadow-inner"
                    />
                </div>
                <p className="text-[10px] font-medium text-slate-400 text-center uppercase tracking-widest">You will be redirected to PayPal's secure login.</p>
            </div>
          )}

          {method === 'COIN' && (
            <div className="p-16 bg-gradient-to-br from-amber-50 to-white border-4 border-amber-100 rounded-[4rem] text-center animate-in slide-in-from-top-4 shadow-xl">
                <div className="w-24 h-24 bg-amber-400 text-white rounded-full flex items-center justify-center mx-auto mb-8 text-5xl shadow-2xl animate-bounce">🪙</div>
                <h4 className="text-2xl font-black text-amber-900 mb-2 uppercase tracking-tight">Mohisa Coins Wallet</h4>
                <p className="text-amber-700/60 font-black text-xs uppercase tracking-[0.3em] mb-8">Asset-Based Payment</p>
                <div className="inline-block px-10 py-5 bg-white rounded-[2rem] border-2 border-amber-200">
                   <span className="text-5xl font-black text-amber-600">650</span>
                   <span className="text-xs font-black text-amber-400 uppercase ml-2 tracking-widest">Available</span>
                </div>
                <p className="mt-8 text-amber-800/40 text-[9px] font-black uppercase tracking-[0.5em]">Coins are generated via gifts and social sync.</p>
            </div>
          )}

          <button
            onClick={handlePay}
            disabled={selectedPlan === null}
            className={`w-full py-10 rounded-[3rem] font-black text-2xl shadow-[0_30px_70px_-15px_rgba(0,0,0,0.3)] hover:scale-[1.01] active:scale-[0.98] transition-all flex items-center justify-center gap-6 disabled:opacity-30 disabled:grayscale ${
                method === 'TELEBIRR' ? 'bg-black text-white' : 
                method === 'MASTERCARD' ? 'bg-red-600 text-white' : 
                method === 'PAYPAL' ? 'bg-blue-600 text-white' : 'bg-amber-500 text-white'
            }`}
          >
            <span>{language === Language.OROMO ? 'KAFFALTIIN XUMURI' : 'COMPLETE TRANSACTION'}</span>
            <span className="text-3xl">➔</span>
          </button>
        </div>
      </div>

      <div className="flex justify-center gap-12 opacity-30 grayscale hover:grayscale-0 transition-all duration-700">
         <div className="flex flex-col items-center">
            <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-1">Encrypted By</span>
            <span className="text-xl font-black text-slate-900">OROSecure™</span>
         </div>
         <div className="w-px h-10 bg-slate-300"></div>
         <div className="flex flex-col items-center">
            <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-1">Status</span>
            <span className="text-xl font-black text-emerald-600">Active</span>
         </div>
      </div>
    </div>
  );
};

export default PaymentSection;
