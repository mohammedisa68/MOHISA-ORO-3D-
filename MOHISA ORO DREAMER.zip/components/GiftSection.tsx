
import React, { useState, useEffect } from 'react';
import { Language, GiftItem } from '../types';

interface GiftSectionProps {
  onToggleToast: (msg: string) => void;
  language: Language;
}

const GiftSection: React.FC<GiftSectionProps> = ({ onToggleToast, language }) => {
  const [activeTab, setActiveTab] = useState<'STORE' | 'MARKET' | 'SOCIAL'>('MARKET');
  const [myGifts, setMyGifts] = useState<GiftItem[]>([]);
  const [checkoutItem, setCheckoutItem] = useState<GiftItem | null>(null);
  const [isProcessingTransaction, setIsProcessingTransaction] = useState(false);
  
  const [marketGifts] = useState<GiftItem[]>([
    { 
      id: 'odaa_legendary_coin', 
      name: 'Legendary Odaa', 
      price: 50000, 
      owner: 'Mohammed_Isa', 
      type: 'heritage', 
      imageUrl: '' 
    },
    { 
      id: 'barcuma_gadaa', 
      name: 'Barcuma Abbaa Gadaa', 
      price: 20000, 
      owner: 'Gadaa_Council', 
      type: 'art', 
      imageUrl: '' 
    },
    { 
      id: 'baallii_feather', 
      name: 'Baallii (The Ostrich Feather)', 
      price: 15000, 
      owner: 'Heritage_Trust', 
      type: 'art', 
      imageUrl: '' 
    }
  ]);

  useEffect(() => {
    const savedGifts = localStorage.getItem('mohisa_my_gifts');
    if (savedGifts) setMyGifts(JSON.parse(savedGifts));
  }, []);

  const saveMyGifts = (updated: GiftItem[]) => {
    setMyGifts(updated);
    localStorage.setItem('mohisa_my_gifts', JSON.stringify(updated));
  };

  const handleProcessPurchase = () => {
    if (!checkoutItem) return;
    setIsProcessingTransaction(true);
    setTimeout(() => {
      const newGift = { ...checkoutItem, id: `bought_${Date.now()}`, owner: 'ME' };
      saveMyGifts([newGift, ...myGifts]);
      setIsProcessingTransaction(false);
      setCheckoutItem(null);
      onToggleToast(language === Language.OROMO ? "Bitamee kuusaa keetti dabalameera!" : "Purchased and added to your vault!");
    }, 2500);
  };

  const CulturalIllustration = ({ type }: { type: string }) => {
    if (type === 'odaa_legendary_coin') {
      return (
        <div className="relative w-full h-full flex items-center justify-center bg-gradient-to-br from-emerald-950 via-emerald-900 to-black overflow-hidden group">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-emerald-400/30 via-transparent to-transparent animate-pulse"></div>
          <svg viewBox="0 0 200 200" className="w-4/5 h-4/5 drop-shadow-[0_20px_40px_rgba(0,0,0,0.8)] animate-float-slow">
            <defs>
              <linearGradient id="trunkGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#5d3a1a" />
                <stop offset="100%" stopColor="#2c1b0a" />
              </linearGradient>
            </defs>
            <ellipse cx="100" cy="180" rx="60" ry="10" fill="rgba(0,0,0,0.4)" />
            <path d="M85 185 Q100 170 100 110 Q100 70 115 185" fill="url(#trunkGrad)" />
            <g className="animate-sway origin-bottom">
                <circle cx="100" cy="70" r="55" fill="#064e3b" />
                <circle cx="65" cy="95" r="45" fill="#065f46" />
                <circle cx="135" cy="95" r="45" fill="#065f46" />
                <circle cx="100" cy="50" r="35" fill="#10b981" className="animate-pulse" />
            </g>
            <circle cx="70" cy="50" r="2.5" fill="white" className="animate-ping" />
            <circle cx="130" cy="70" r="2" fill="white" className="animate-ping [animation-delay:1.5s]" />
            <circle cx="100" cy="90" r="3" fill="#facc15" className="animate-pulse shadow-xl" />
          </svg>
        </div>
      );
    }
    if (type === 'barcuma_gadaa') {
      return (
        <div className="relative w-full h-full flex items-center justify-center bg-gradient-to-br from-amber-950 via-amber-900 to-black overflow-hidden">
          <div className="absolute inset-0 bg-[conic-gradient(from_0deg,_transparent,_rgba(245,158,11,0.1),_transparent)] animate-spin-slow"></div>
          <svg viewBox="0 0 200 200" className="w-3/5 h-3/5 animate-bounce-slow drop-shadow-[0_25px_35px_rgba(0,0,0,0.7)]">
             <defs>
               <radialGradient id="seatGrad">
                 <stop offset="0%" stopColor="#fbbf24" />
                 <stop offset="100%" stopColor="#92400e" />
               </radialGradient>
             </defs>
             <ellipse cx="100" cy="70" rx="75" ry="32" fill="url(#seatGrad)" stroke="#78350f" strokeWidth="5" />
             <path d="M55 90 L25 185" stroke="#451a03" strokeWidth="16" strokeLinecap="round" className="animate-sway-legs" />
             <path d="M100 100 L100 195" stroke="#451a03" strokeWidth="16" strokeLinecap="round" />
             <path d="M145 90 L175 185" stroke="#451a03" strokeWidth="16" strokeLinecap="round" className="animate-sway-legs-reverse" />
             <path d="M50 70 Q100 90 150 70" stroke="rgba(255,255,255,0.3)" strokeWidth="4" fill="none" />
             <circle cx="100" cy="70" r="6" fill="rgba(255,255,255,0.5)" className="animate-pulse" />
          </svg>
        </div>
      );
    }
    if (type === 'baallii_feather') {
      return (
        <div className="relative w-full h-full flex items-center justify-center bg-gradient-to-br from-slate-900 to-black overflow-hidden">
           <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_rgba(255,255,255,0.1),_transparent)] animate-pulse"></div>
           <svg viewBox="0 0 200 200" className="w-3/4 h-3/4 animate-float drop-shadow-[0_0_30px_rgba(255,255,255,0.5)]">
             <defs>
               <linearGradient id="featherGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                 <stop offset="0%" stopColor="#ffffff" />
                 <stop offset="100%" stopColor="#cbd5e1" />
               </linearGradient>
             </defs>
             <path d="M100 190 Q100 100 160 20" stroke="white" strokeWidth="5" fill="none" strokeLinecap="round" className="animate-draw-path" />
             <g className="animate-sway-feather origin-bottom">
               {Array.from({ length: 20 }).map((_, i) => (
                 <React.Fragment key={i}>
                   <path d={`M100 ${185 - i * 8} Q60 ${165 - i * 8} 40 ${145 - i * 8}`} stroke="white" strokeWidth="1.5" opacity={1 - i * 0.045} />
                   <path d={`M100 ${185 - i * 8} Q140 ${165 - i * 8} 160 ${145 - i * 8}`} stroke="white" strokeWidth="1.5" opacity={1 - i * 0.045} />
                 </React.Fragment>
               ))}
             </g>
             <circle cx="160" cy="20" r="4" fill="white" className="animate-ping" />
           </svg>
        </div>
      );
    }
    return <div className="w-full h-full bg-slate-100 flex items-center justify-center">🎁</div>;
  };

  return (
    <div className="max-w-6xl mx-auto space-y-12 pb-24 animate-in fade-in duration-1000">
      {/* CHECKOUT MODAL */}
      {checkoutItem && (
        <div className="fixed inset-0 z-[500] bg-slate-950/95 backdrop-blur-2xl flex items-center justify-center p-6">
           <div className="bg-white rounded-[4rem] w-full max-w-xl overflow-hidden shadow-2xl relative border border-white/20 animate-in zoom-in-95 duration-400">
              {isProcessingTransaction && (
                <div className="absolute inset-0 z-10 bg-white/95 backdrop-blur-md flex flex-col items-center justify-center">
                   <div className="w-20 h-20 border-4 border-slate-200 border-t-emerald-600 rounded-full animate-spin mb-6"></div>
                   <p className="font-black text-[11px] uppercase tracking-[0.5em] text-emerald-600">Processing Legacy Sync...</p>
                </div>
              )}
              <div className="h-72 relative overflow-hidden">
                 <CulturalIllustration type={checkoutItem.id} />
              </div>
              <div className="p-12 space-y-8 text-center">
                 <div className="space-y-2">
                    <h3 className="text-4xl font-black uppercase italic tracking-tighter text-slate-900">{checkoutItem.name}</h3>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Premium Oromo Asset</p>
                 </div>
                 <p className="text-6xl font-black text-emerald-600 tracking-tighter drop-shadow-sm">{checkoutItem.price.toLocaleString()} <span className="text-2xl">ETB</span></p>
                 <button onClick={handleProcessPurchase} className="w-full py-9 bg-black text-white rounded-[2.5rem] font-black uppercase tracking-[0.4em] shadow-2xl hover:bg-emerald-600 active:scale-95 transition-all text-lg border-b-8 border-slate-800">
                    KAFFALTIIN XUMURI
                 </button>
                 <button onClick={() => setCheckoutItem(null)} className="px-10 py-3 text-[10px] font-black uppercase text-slate-400 hover:text-red-600 transition-colors">DHAABI (CANCEL)</button>
              </div>
           </div>
        </div>
      )}

      {/* TABS NAVIGATION */}
      <div className="flex bg-white/80 backdrop-blur-3xl p-3 rounded-[3.5rem] border border-white gap-3 shadow-2xl z-40 max-w-2xl mx-auto ring-1 ring-black/5">
        {['STORE', 'MARKET', 'SOCIAL'].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab as any)}
            className={`flex-1 py-5 px-6 rounded-[2rem] font-black text-[11px] uppercase tracking-[0.2em] transition-all whitespace-nowrap ${
              activeTab === tab ? 'bg-black text-white shadow-2xl scale-[1.03]' : 'text-slate-400 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            {tab === 'STORE' ? (language === Language.OROMO ? 'Suuqii' : 'My Vault') :
             tab === 'MARKET' ? (language === Language.OROMO ? 'Gabaa' : 'Gift Store') :
             'Social'}
          </button>
        ))}
      </div>

      {activeTab === 'MARKET' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 pt-8">
          {marketGifts.map(gift => (
            <div key={gift.id} className="bg-white border border-slate-100 rounded-[4rem] p-8 flex flex-col items-center group shadow-xl hover:-translate-y-6 transition-all duration-700 hover:shadow-[0_40px_80px_-20px_rgba(0,0,0,0.15)]">
              <div className="w-full aspect-[4/5] rounded-[3.5rem] overflow-hidden mb-10 shadow-2xl relative ring-4 ring-slate-50">
                <CulturalIllustration type={gift.id} />
              </div>
              <div className="text-center space-y-2 mb-10">
                <h5 className="font-black text-slate-900 uppercase tracking-tighter text-3xl italic">{gift.name}</h5>
                <p className="text-emerald-600 font-black text-xl tracking-tighter">{gift.price.toLocaleString()} ETB</p>
              </div>
              <button onClick={() => setCheckoutItem(gift)} className="w-full py-7 bg-black text-white rounded-[2.2rem] font-black text-xs uppercase tracking-[0.3em] hover:bg-emerald-600 transition-all shadow-xl active:scale-95">ACQUIRE ASSET</button>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'STORE' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 pt-8">
           {myGifts.length === 0 ? (
             <div className="col-span-full py-32 text-center bg-white/40 rounded-[4rem] border-4 border-dashed border-white/60">
               <div className="text-7xl mb-6 opacity-20">📦</div>
               <p className="text-slate-400 font-black uppercase tracking-[0.5em] italic">Kuusaa keessa homtuu hin jiru.</p>
             </div>
           ) : (
             myGifts.map(gift => (
               <div key={gift.id} className="bg-white p-8 rounded-[4rem] shadow-2xl border border-slate-50 flex flex-col items-center group transition-all hover:scale-105">
                  <div className="w-full aspect-square rounded-[3rem] overflow-hidden mb-8 shadow-inner ring-1 ring-slate-100">
                     <CulturalIllustration type={gift.id.includes('bought_') ? marketGifts.find(mg => mg.name === gift.name)?.id || 'odaa_legendary_coin' : gift.id} />
                  </div>
                  <h6 className="font-black uppercase text-slate-900 text-xl italic tracking-tighter">{gift.name}</h6>
                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.4em] mt-2">Authenticated Owner</p>
               </div>
             ))
           )}
        </div>
      )}

      <style>{`
        @keyframes float-slow {
          0%, 100% { transform: translateY(0) rotate(0); }
          50% { transform: translateY(-20px) rotate(3deg); }
        }
        @keyframes bounce-slow {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.1); }
        }
        @keyframes sway {
          0%, 100% { transform: rotate(-3deg); }
          50% { transform: rotate(3deg); }
        }
        @keyframes sway-feather {
          0%, 100% { transform: rotate(-8deg) translateX(-5px); }
          50% { transform: rotate(8deg) translateX(5px); }
        }
        @keyframes draw-path {
          from { stroke-dasharray: 0 1000; }
          to { stroke-dasharray: 1000 0; }
        }
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes sway-legs {
          0%, 100% { transform: translateX(0); }
          50% { transform: translateX(-5px); }
        }
        .animate-float-slow { animation: float-slow 7s ease-in-out infinite; }
        .animate-bounce-slow { animation: bounce-slow 5s ease-in-out infinite; }
        .animate-sway { animation: sway 5s ease-in-out infinite; }
        .animate-sway-feather { animation: sway-feather 6s ease-in-out infinite; }
        .animate-draw-path { animation: draw-path 3s ease-out forwards; }
        .animate-spin-slow { animation: spin-slow 20s linear infinite; }
        .animate-sway-legs { animation: sway-legs 4s ease-in-out infinite; }
        .animate-sway-legs-reverse { animation: sway-legs 4s ease-in-out infinite reverse; }
      `}</style>
    </div>
  );
};

export default GiftSection;
