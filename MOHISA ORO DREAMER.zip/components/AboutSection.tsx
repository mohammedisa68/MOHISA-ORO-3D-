
import React, { useEffect, useState } from 'react';
import { UserStats, Language } from '../types';
import { dbService } from '../services/dbService';

interface AboutSectionProps {
  language: Language;
  stats: UserStats;
}

const AboutSection: React.FC<AboutSectionProps> = ({ language, stats: localStats }) => {
  const [globalStats, setGlobalStats] = useState<UserStats | null>(null);
  const logoUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=60";

  useEffect(() => {
    const fetchGlobal = async () => {
      const data = await dbService.getGlobalStats();
      if (data) setGlobalStats(data as any);
    };
    fetchGlobal();
  }, []);

  const displayStats = globalStats || localStats;

  const content: Record<string, any> = {
    om: {
      title: 'MOHISA ORO AI',
      desc1: 'MOHISA ORO platformii Mohammed Isa\'n qophaa\'ee dha.',
      desc2: 'Kaayyoon keenya teeknoolojii ammayyaa aadaa fi afaan keenya (Afaan Oromoo) waliin wal-simsiisuu dha.',
      developed: 'MOHISA ORO AI Developed by Mohammed Isa 2026',
      reportTitle: 'GABAASA SIRNAA (SYSTEM REPORT)',
      stats: ['Sagalee Uumame', 'Suuraa Uumame', 'Video Uumame', 'Likes', 'Shares', 'Downloads', 'App Clicks', 'Live (Daqiiqaa)'],
      info: 'MOHISA ORO Analytics'
    },
    en: {
      title: 'MOHISA ORO AI',
      desc1: 'MOHISA ORO is a revolutionary platform developed by Mohammed Isa.',
      desc2: 'Our mission is to bridge the gap between advanced technology and local culture.',
      developed: 'MOHISA ORO AI Developed by Mohammed Isa 2026',
      reportTitle: 'MOHISA SYSTEM REPORT',
      stats: ['Audios Created', 'Images Generated', 'Videos Created', 'Total Likes', 'Total Shares', 'Total Downloads', 'Total App Clicks', 'Total Live Minutes'],
      info: 'MOHISA ORO Analytics'
    }
  };

  const currentContent = content[language === Language.OROMO ? 'om' : 'en'];

  const reportItems = [
    { label: currentContent.stats[0], value: displayStats.audioCount, icon: '🎙️' },
    { label: currentContent.stats[1], value: displayStats.imageCount, icon: '🎨' },
    { label: currentContent.stats[2], value: displayStats.videoCount, icon: '🎬' },
    { label: currentContent.stats[3], value: displayStats.likes, icon: '❤️' },
    { label: currentContent.stats[4], value: displayStats.shares, icon: '🔗' },
    { label: currentContent.stats[5], value: displayStats.downloads, icon: '📥' },
    { label: currentContent.stats[6], value: displayStats.clicks, icon: '🖱️' },
    { label: currentContent.stats[7], value: displayStats.liveMinutes, icon: '⏳' },
  ];

  return (
    <div className="space-y-12 animate-in fade-in zoom-in-95 duration-700 pb-20">
      <div className="glass-card rounded-[3rem] p-8 sm:p-14 border border-white relative overflow-hidden bg-white/80 backdrop-blur-xl">
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-10">
          <div className="w-40 h-40 rounded-[2.5rem] overflow-hidden shadow-2xl border-4 border-white transform rotate-2">
              <img src={logoUrl} className="w-full h-full object-cover" />
          </div>
          
          <div className="flex-1 text-center md:text-left">
            <h2 className="text-4xl font-black text-slate-900 mb-4 tracking-tighter uppercase italic">{currentContent.title}</h2>
            <div className="prose prose-slate max-w-xl mb-6">
              <p className="text-slate-900 font-black text-lg mb-2 italic">"Dreamer doesn't die!!!"</p>
              <p className="text-slate-600 font-medium text-sm leading-relaxed">{currentContent.desc1} {currentContent.desc2}</p>
            </div>
            <p className="text-[10px] font-black text-slate-900 uppercase tracking-widest flex items-center justify-center md:justify-start gap-3">
               <span className="w-8 h-1 bg-red-600 rounded-full"></span>
               {currentContent.developed}
            </p>
          </div>
        </div>
      </div>

      <div className="glass-card rounded-[3.5rem] p-10 sm:p-16 bg-black text-white shadow-2xl overflow-hidden relative">
         <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-red-600 via-amber-500 to-black"></div>
         
         <div className="text-center mb-12">
            <h3 className="text-4xl font-black italic tracking-tighter uppercase mb-2">{currentContent.reportTitle}</h3>
            <p className="text-slate-400 font-black text-[9px] uppercase tracking-[0.4em]">{currentContent.info}</p>
         </div>

         <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {reportItems.map((item, idx) => (
              <div key={idx} className="bg-white/5 backdrop-blur-md p-6 rounded-[2rem] border border-white/10 flex flex-col items-center group hover:bg-white/10 transition-all border-b-4 border-b-transparent hover:border-b-red-600">
                <span className="text-2xl mb-2 group-hover:scale-110 transition-transform">{item.icon}</span>
                <span className="text-3xl font-black text-white mb-1 tracking-tighter">{item.value.toLocaleString()}</span>
                <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest text-center">{item.label}</span>
              </div>
            ))}
         </div>

         <div className="mt-12 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="text-center md:text-left">
               <h5 className="text-2xl font-black uppercase italic tracking-widest text-white/90">Invincible app</h5>
               <p className="text-[10px] font-bold text-slate-400 mt-1 uppercase">MOHISA ORO AI © 2026</p>
            </div>
            <div className="px-8 py-3 bg-red-600 rounded-full font-black text-[9px] uppercase tracking-widest animate-pulse shadow-xl">
               SYSTEM STABLE & SECURE
            </div>
         </div>
      </div>
    </div>
  );
};

export default AboutSection;
