
import React from 'react';
import { Language } from '../types';

interface ShareAwardButtonProps {
  language: Language;
}

const ShareAwardButton: React.FC<ShareAwardButtonProps> = ({ language }) => {
  const handleShare = async () => {
    const texts = {
      om: 'MOHISA ORO AI: Barreeffama gara sagaleetti, suuraa fi video AI Afaan Oromootiin hojjechuuf kana fayyadamaa!',
      en: 'MOHISA ORO AI: Use this for Text-to-Speech, Image & Video AI in Afaan Oromo and more!',
      ar: 'MOHISA ORO AI: استخدم هذا التطبيق لتحويل النص إلى صوت وإنشاء الصور والفيديوهات بالذكاء الاصطناعي!'
    };

    let shareUrl = window.location.href;
    if (shareUrl.startsWith('blob:') || shareUrl.startsWith('data:')) {
      shareUrl = window.location.origin;
    }

    const shareData: ShareData = {
      title: 'MOHISA ORO AI',
      text: `${texts[language as keyof typeof texts] || texts.en} \n\nDeveloped by Mohammed Isa`,
      url: shareUrl,
    };

    try {
      if (navigator.share) {
        try {
          await navigator.share(shareData);
        } catch (innerErr) {
          await navigator.share({
            title: shareData.title,
            text: `${shareData.text}\n\nLink: ${shareUrl}`
          });
        }
      } else {
        throw new Error('Web Share API not supported');
      }
    } catch (err) {
      try {
        window.focus();
        await navigator.clipboard.writeText(`${texts[language as keyof typeof texts] || texts.en} - ${shareUrl}`);
        console.log("App link copied to clipboard.");
      } catch (clipErr) {
        console.warn("Clipboard copy also failed", clipErr);
      }
    }
  };

  return (
    <div className="relative group">
      <button
        onClick={handleShare}
        className="w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-red-600 via-red-500 to-black text-white rounded-[1.5rem] sm:rounded-[1.8rem] shadow-2xl flex items-center justify-center hover:scale-110 active:scale-95 transition-all border-2 border-white/30 animate-float"
      >
        <svg className="w-7 h-7 sm:w-8 sm:h-8 text-white group-hover:rotate-12 transition-transform drop-shadow-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
        </svg>
      </button>
      
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0) rotate(0); }
          50% { transform: translateY(-5px) rotate(2deg); }
        }
        .animate-float {
          animation: float 4s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default ShareAwardButton;
