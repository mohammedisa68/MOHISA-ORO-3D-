
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { ImageData, Language } from '../types';

interface ImageSectionProps {
  onToggleToast: (msg: string) => void;
  language: Language;
}

const ImageSection: React.FC<ImageSectionProps> = ({ onToggleToast, language }) => {
  const [prompt, setPrompt] = useState('');
  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isVoicePrompting, setIsVoicePrompting] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [history, setHistory] = useState<ImageData[]>([]);
  
  // Tuner States
  const [tunerImage, setTunerImage] = useState<string | null>(null);
  const [tunerQuality, setTunerQuality] = useState(0.8);
  const [tunerScale, setTunerScale] = useState(1.0);
  const [currentSize, setCurrentSize] = useState<number>(0);
  const [tunedDataUrl, setTunedDataUrl] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('mohisa_image_history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as ImageData[];
        setHistory(parsed);
      } catch (e) { console.error(e); }
    }
    const savedPrompt = localStorage.getItem('mohisa_image_prompt');
    if (savedPrompt) setPrompt(savedPrompt);
  }, []);

  useEffect(() => {
    localStorage.setItem('mohisa_image_prompt', prompt);
  }, [prompt]);

  const calculateSize = (dataUrl: string) => {
    const base64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
    const padding = (base64.match(/=/g) || []).length;
    const size = (base64.length * 0.75) - padding;
    return size;
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes.toFixed(0)} B`;
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(2)} KB`;
    return `${(bytes / 1048576).toFixed(2)} MB`;
  };

  const processTuning = useCallback(() => {
    if (!tunerImage) return;
    const img = new Image();
    img.src = tunerImage;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const width = img.width * tunerScale;
      const height = img.height * tunerScale;
      canvas.width = width;
      canvas.height = height;

      ctx.drawImage(img, 0, 0, width, height);
      const dataUrl = canvas.toDataURL('image/jpeg', tunerQuality);
      setTunedDataUrl(dataUrl);
      setCurrentSize(calculateSize(dataUrl));
    };
  }, [tunerImage, tunerQuality, tunerScale]);

  useEffect(() => {
    processTuning();
  }, [processTuning]);

  const startVoicePrompt = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      const chunks: BlobPart[] = [];
      recorder.ondataavailable = (e: BlobEvent) => {
        if (e.data && e.data.size > 0) chunks.push(e.data);
      };
      recorder.onstop = async () => {
        const blob = new Blob(chunks, { type: 'audio/wav' });
        setIsGenerating(true);
        setStatusMessage(language === Language.OROMO ? 'Sagalee jijjiiraa jira...' : 'Converting voice...');
        try {
          const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
          const reader = new FileReader();
          reader.readAsDataURL(blob);
          reader.onloadend = async () => {
            const base64Data = (reader.result as string).split(',')[1];
            const response = await ai.models.generateContent({
              model: 'gemini-3-flash-preview',
              contents: { parts: [{ inlineData: { data: base64Data, mimeType: 'audio/wav' } }, { text: "Transcribe this short image description." }] }
            });
            setPrompt(response.text || '');
            setIsGenerating(false);
          };
        } catch (e) { setIsGenerating(false); }
      };
      recorder.start();
      setIsVoicePrompting(true);
    } catch (e) { onToggleToast("Mic error."); }
  };

  const stopVoicePrompt = () => {
    mediaRecorderRef.current?.stop();
    setIsVoicePrompting(false);
  };

  const applyWatermark = (dataUrl: string): Promise<string> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.src = dataUrl;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width; canvas.height = img.height;
        const ctx = canvas.getContext('2d')!;
        ctx.drawImage(img, 0, 0);
        ctx.font = `900 ${img.width / 20}px "Plus Jakarta Sans"`;
        ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
        ctx.textAlign = 'right';
        ctx.fillText('MOHISA ORO AI', img.width * 0.95, img.height * 0.95);
        resolve(canvas.toDataURL('image/png'));
      };
    });
  };

  const generateImage = async () => {
    if (!prompt.trim() && selectedImages.length === 0) return;
    setIsGenerating(true);
    setStatusMessage(language === Language.OROMO ? 'Suuraa qopheessaa jira...' : 'Generating image...');
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      let response: GenerateContentResponse;
      if (selectedImages.length > 0) {
        const parts = selectedImages.map(img => ({ inlineData: { data: img.split(',')[1], mimeType: 'image/png' } }));
        parts.push({ text: `Edit this based on: ${prompt}` } as any);
        response = await ai.models.generateContent({ model: 'gemini-2.5-flash-image', contents: { parts } });
      } else {
        response = await ai.models.generateContent({ model: 'gemini-2.5-flash-image', contents: { parts: [{ text: `Cinematic image: ${prompt}` }] } });
      }
      const part = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
      if (part?.inlineData) {
        const rawUrl = `data:image/png;base64,${part.inlineData.data}`;
        const finalUrl = await applyWatermark(rawUrl);
        const newHistory = [{ url: finalUrl, prompt, timestamp: Date.now() }, ...history].slice(0, 10);
        setHistory(newHistory);
        localStorage.setItem('mohisa_image_history', JSON.stringify(newHistory));
        onToggleToast(language === Language.OROMO ? "Suuraan Qophaa'eera!" : "Image Generated!");
        setTunerImage(finalUrl);
      }
    } catch (err) { onToggleToast("Error."); } finally { setIsGenerating(false); }
  };

  const deleteHistoryItem = (timestamp: number) => {
    const updated = history.filter(item => item.timestamp !== timestamp);
    setHistory(updated);
    localStorage.setItem('mohisa_image_history', JSON.stringify(updated));
    onToggleToast(language === Language.OROMO ? "Suuraan haqameera." : "Image deleted.");
  };

  const clearAllHistory = () => {
    if (window.confirm(language === Language.OROMO ? "Suuraa hunda balleessuu barbaadduu?" : "Are you sure you want to clear all history?")) {
      setHistory([]);
      localStorage.removeItem('mohisa_image_history');
      onToggleToast(language === Language.OROMO ? "Kuusaan suuraa hunduu haqameera." : "All image history cleared.");
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-12 pb-20">
      {/* 1. TUNER SECTION */}
      {tunerImage && (
        <div className="glass-card rounded-[3rem] p-8 sm:p-12 border-t-8 border-t-indigo-600 shadow-2xl animate-in zoom-in duration-500">
           <div className="flex justify-between items-center mb-10">
              <h3 className="text-2xl font-black flex items-center gap-4">
                 <span className="w-12 h-12 bg-indigo-600 text-white rounded-2xl flex items-center justify-center text-xl shadow-lg">📏</span>
                 {language === Language.OROMO ? 'DHANGALA\'AA SIZE' : 'IMAGE SIZE TUNER'}
              </h3>
              <button onClick={() => setTunerImage(null)} className="text-[10px] font-black uppercase text-slate-400 hover:text-red-600">Dismiss</button>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="space-y-8">
                 <div className="space-y-4">
                    <div className="flex justify-between items-center">
                       <label className="text-[10px] font-black uppercase tracking-widest text-slate-500">{language === Language.OROMO ? 'Qulqullina' : 'Quality'}</label>
                       <span className="text-xs font-bold">{Math.round(tunerQuality * 100)}%</span>
                    </div>
                    <input 
                      type="range" min="0.1" max="1.0" step="0.05" 
                      value={tunerQuality} onChange={(e) => setTunerQuality(parseFloat(e.target.value))} 
                      className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                    />
                 </div>

                 <div className="space-y-4">
                    <div className="flex justify-between items-center">
                       <label className="text-[10px] font-black uppercase tracking-widest text-slate-500">{language === Language.OROMO ? 'Guddina (Scale)' : 'Scale'}</label>
                       <span className="text-xs font-bold">{Math.round(tunerScale * 100)}%</span>
                    </div>
                    <input 
                      type="range" min="0.1" max="2.0" step="0.1" 
                      value={tunerScale} onChange={(e) => setTunerScale(parseFloat(e.target.value))} 
                      className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                    />
                 </div>

                 <div className="p-8 bg-slate-50 rounded-[2rem] border-2 border-slate-100 text-center">
                    <p className="text-[9px] font-black uppercase text-slate-400 tracking-[0.3em] mb-2">{language === Language.OROMO ? 'Size Ammaa' : 'Current Estimated Size'}</p>
                    <h4 className={`text-5xl font-black tracking-tighter ${currentSize > 5242880 ? 'text-red-600' : 'text-slate-900'}`}>
                       {formatSize(currentSize)}
                    </h4>
                    {currentSize > 5242880 && <p className="text-[9px] font-bold text-red-500 mt-2 uppercase">Limit: 5MB Exceeded</p>}
                 </div>

                 <a 
                   href={tunedDataUrl || ''} 
                   download={`MOHISA-TUNED-${Date.now()}.jpg`}
                   className={`w-full py-6 rounded-[2rem] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-4 transition-all shadow-xl ${currentSize > 5242880 ? 'bg-slate-200 text-slate-400 pointer-events-none' : 'bg-black text-white hover:bg-slate-900 active:scale-95'}`}
                 >
                   <span>📥</span>
                   {language === Language.OROMO ? 'BITAMEE BUUFADHU' : 'DOWNLOAD TUNED IMAGE'}
                 </a>
              </div>

              <div className="rounded-[2.5rem] overflow-hidden border-4 border-slate-100 bg-slate-50 aspect-square flex items-center justify-center relative">
                 {tunedDataUrl ? (
                   <img src={tunedDataUrl} className="max-w-full max-h-full object-contain" alt="Tuned" />
                 ) : (
                   <div className="animate-pulse text-slate-300">Processing...</div>
                 )}
              </div>
           </div>
        </div>
      )}

      {/* 2. GENERATOR SECTION */}
      <div className="glass-card rounded-[3rem] p-8 sm:p-12 border-t-8 border-t-green-600 relative overflow-hidden shadow-2xl">
        {isGenerating && (
          <div className="absolute inset-0 bg-white/80 backdrop-blur-md z-20 flex flex-col items-center justify-center">
             <div className="w-16 h-16 border-4 border-green-200 border-t-green-600 rounded-full animate-spin mb-4"></div>
             <p className="font-black text-green-700 uppercase tracking-widest text-xs">{statusMessage}</p>
          </div>
        )}
        
        <h3 className="text-2xl font-black flex items-center gap-4 mb-8">
           <span className="w-12 h-12 bg-green-600 text-white rounded-2xl flex items-center justify-center text-xl shadow-lg">🎨</span>
           SUURAA
        </h3>
        
        <div className="space-y-8">
          <div className="flex flex-wrap gap-4">
            {selectedImages.map((img, idx) => (
              <div key={idx} className="relative w-28 h-28 rounded-2xl overflow-hidden border-4 border-green-50 shadow-md">
                <img src={img} className="w-full h-full object-cover" alt="selected" />
                <button onClick={() => setSelectedImages(p => p.filter((_, i) => i !== idx))} className="absolute top-2 right-2 w-6 h-6 bg-red-600 text-white rounded-full text-xs">✕</button>
              </div>
            ))}
            <button onClick={() => fileInputRef.current?.click()} className="w-28 h-28 rounded-2xl border-4 border-dashed border-slate-100 flex flex-col items-center justify-center text-slate-300 hover:border-green-400 hover:bg-green-50 transition-all">
                <span className="text-3xl mb-1">+</span>
                <span className="text-[9px] font-black uppercase tracking-widest">Dabali</span>
            </button>
            <input type="file" ref={fileInputRef} multiple className="hidden" accept="image/*" onChange={e => {
              if (e.target.files) {
                Array.from(e.target.files).forEach(f => {
                  const r = new FileReader();
                  r.onloadend = () => {
                    const res = r.result as string;
                    setSelectedImages(p => [...p, res]);
                    if (selectedImages.length === 0) setTunerImage(res);
                  };
                  r.readAsDataURL(f as Blob);
                });
              }
            }} />
          </div>

          <div className="relative">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={language === Language.OROMO ? "Suuraa akkamii uumuu barbaadda?..." : "Describe the image..."}
              className="w-full h-40 p-8 bg-slate-50 border-2 border-slate-100 rounded-[2.5rem] focus:border-green-500 outline-none transition-all text-xl shadow-inner resize-none font-medium"
            />
            <button 
              onClick={isVoicePrompting ? stopVoicePrompt : startVoicePrompt}
              className={`absolute bottom-6 right-6 p-4 rounded-2xl transition-all shadow-lg ${isVoicePrompting ? 'bg-red-600 text-white animate-pulse' : 'bg-green-600 text-white hover:scale-110'}`}
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
            </button>
          </div>

          <button
            onClick={generateImage}
            disabled={isGenerating || (!prompt.trim() && selectedImages.length === 0)}
            className="w-full py-7 bg-black text-white rounded-[2.5rem] font-black text-2xl hover:bg-slate-800 transition-all shadow-2xl active:scale-[0.98]"
          >
            {language === Language.OROMO ? "SUURAA UUMI" : "GENERATE IMAGE"}
          </button>
        </div>
      </div>

      {/* 3. HISTORY GRID HEADER */}
      {history.length > 0 && (
        <div className="flex justify-between items-center px-4 animate-in fade-in">
           <h4 className="text-xl font-black uppercase tracking-tighter italic text-slate-900">{language === Language.OROMO ? 'SEENAA SUURAA' : 'IMAGE HISTORY'}</h4>
           <button 
             onClick={clearAllHistory}
             className="px-6 py-2 bg-red-50 text-red-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-red-100 hover:bg-red-600 hover:text-white transition-all shadow-sm"
           >
             {language === Language.OROMO ? 'HUNDA HAQI (CLEAR ALL)' : 'CLEAR ALL'}
           </button>
        </div>
      )}

      {/* 4. HISTORY GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {history.map(img => (
          <div key={img.timestamp} className="glass-card overflow-hidden rounded-[3rem] group relative shadow-xl border border-white">
            <img src={img.url} className="w-full aspect-square object-cover" alt="History" />
            <div className="absolute inset-x-0 bottom-0 p-8 bg-gradient-to-t from-black via-black/40 to-transparent flex justify-between items-end">
               <div className="flex flex-col gap-2">
                  <button 
                    onClick={() => deleteHistoryItem(img.timestamp)}
                    className="text-white text-[10px] font-black uppercase tracking-widest bg-red-600/80 backdrop-blur-md px-4 py-2 rounded-full hover:bg-red-600 transition-all border border-red-400/50"
                  >
                    {language === Language.OROMO ? 'HAQI (CLEAR)' : 'CLEAR'}
                  </button>
                  <button onClick={() => setTunerImage(img.url)} className="text-white text-[10px] font-black uppercase tracking-widest bg-indigo-600/80 backdrop-blur-md px-4 py-2 rounded-full hover:bg-indigo-600 transition-all border border-indigo-400/50">Resize</button>
               </div>
               <a href={img.url} download={`MOHISA-ORO-AI-${img.timestamp}.png`} className="p-4 bg-white text-black rounded-2xl shadow-xl hover:scale-110 transition-transform"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4" /></svg></a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ImageSection;
