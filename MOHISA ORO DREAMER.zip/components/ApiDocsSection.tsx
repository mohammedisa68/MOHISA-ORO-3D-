
import React, { useState } from 'react';
import { Language } from '../types';

interface ApiDocsSectionProps {
  language: Language;
}

const ApiDocsSection: React.FC<ApiDocsSectionProps> = ({ language }) => {
  const [activeEndpoint, setActiveEndpoint] = useState('TTS');

  const docs = {
    TTS: {
      title: 'Afaan Oromo TTS API',
      desc: language === Language.OROMO ? 'Barreeffama Afaan Oromoo gara sagaleetti jijjiiruuf.' : 'Convert Afaan Oromo text to natural speech audio.',
      endpoint: 'POST /v1/generate-voice',
      code: `// Example request for Afaan Oromo TTS
const response = await ai.models.generateContent({
  model: "gemini-2.5-flash-preview-tts",
  contents: [{ parts: [{ text: "Akkam jirtu?" }] }],
  config: {
    speechConfig: { 
      voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } 
    }
  }
});`
    },
    PAYMENT: {
      title: 'Payment Integration',
      desc: language === Language.OROMO ? 'Sistama kaffaltii Telebirr fi MasterCard.' : 'Secure payment gateway for Telebirr and Card transactions.',
      endpoint: 'POST /v1/process-payment',
      code: `// Secure payment validation
const initiateTelebirr = async (amount, phone) => {
  const result = await paymentGateway.start({
    provider: "TELEBIRR",
    amount: amount,
    currency: "ETB",
    callback: "https://mohisa-oro.com/verify"
  });
  return result.status === 'SUCCESS';
};`
    },
    IMAGE: {
      title: 'Visual AI Engine',
      desc: language === Language.OROMO ? 'Suuraa AI dhaan uumuuf.' : 'Generate or edit high-quality images using AI.',
      endpoint: 'POST /v1/create-image',
      code: `// Image generation sample
const image = await ai.models.generateContent({
  model: 'gemini-2.5-flash-image',
  contents: { parts: [{ text: "Oromo cultural horse race" }] },
  config: { aspectRatio: "16:9" }
});`
    }
  };

  const current = docs[activeEndpoint as keyof typeof docs];

  return (
    <div className="max-w-6xl mx-auto space-y-12 animate-in fade-in duration-700">
      <div className="glass-card rounded-[4rem] p-10 sm:p-20 border-l-[16px] border-l-black shadow-2xl bg-white/95">
        <div className="flex flex-col md:flex-row gap-16">
          
          {/* SIDEBAR */}
          <div className="w-full md:w-80 space-y-4">
             <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.5em] mb-8">API Reference</h4>
             {Object.keys(docs).map(key => (
               <button 
                key={key}
                onClick={() => setActiveEndpoint(key)}
                className={`w-full p-6 rounded-[2rem] text-left transition-all border-2 flex items-center justify-between ${activeEndpoint === key ? 'bg-black text-white border-black shadow-xl scale-105' : 'bg-slate-50 text-slate-400 border-slate-100 hover:border-slate-300'}`}
               >
                 <span className="font-black text-xs uppercase tracking-widest">{key}</span>
                 {activeEndpoint === key && <span className="animate-pulse">●</span>}
               </button>
             ))}
          </div>

          {/* CONTENT */}
          <div className="flex-1 space-y-10">
            <div className="space-y-4">
               <div className="inline-block px-4 py-1 bg-red-100 text-red-600 rounded-full text-[9px] font-black uppercase tracking-widest">v5.0 Stable</div>
               <h2 className="text-4xl sm:text-6xl font-black tracking-tighter uppercase italic">{current.title}</h2>
               <p className="text-xl text-slate-500 font-medium italic">"{current.desc}"</p>
            </div>

            <div className="p-8 bg-slate-900 rounded-[2.5rem] shadow-inner border border-white/10">
               <div className="flex justify-between items-center mb-6">
                  <span className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">{current.endpoint}</span>
                  <button className="text-[10px] font-black text-slate-500 hover:text-white transition-colors">COPY ENDPOINT</button>
               </div>
               <pre className="text-slate-300 font-mono text-sm overflow-x-auto p-4 leading-relaxed no-scrollbar">
                 <code>{current.code}</code>
               </pre>
            </div>

            <div className="grid grid-cols-2 gap-6">
               <div className="p-8 bg-slate-50 rounded-[2rem] border border-slate-100">
                  <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Auth Header</h5>
                  <code className="text-xs font-bold text-slate-900">Bearer {process.env.API_KEY?.slice(0, 10)}...</code>
               </div>
               <div className="p-8 bg-slate-50 rounded-[2rem] border border-slate-100">
                  <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Response Type</h5>
                  <code className="text-xs font-bold text-slate-900">application/json</code>
               </div>
            </div>
          </div>
        </div>
      </div>

      <div className="p-10 bg-black rounded-[3rem] text-white flex items-center justify-between shadow-2xl">
         <div>
            <h4 className="text-xl font-black mb-1 uppercase tracking-tight">Technical Support</h4>
            <p className="text-slate-400 text-sm font-medium">For developer keys, contact Mohammed Isa.</p>
         </div>
         <button className="px-10 py-4 bg-white text-black rounded-full font-black text-[10px] uppercase tracking-widest hover:bg-slate-200 transition-all">Support Center</button>
      </div>
    </div>
  );
};

export default ApiDocsSection;
