
import { supabase } from '../supabase';

export const mediaService = {
  /**
   * Uploads a file (Blob/File) to the 'media' bucket.
   * Folders are organized by User ID for security.
   */
  async uploadMedia(file: Blob | File, folder: 'audio' | 'images' | 'videos'): Promise<string | null> {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) throw new Error("Not authenticated");

      const userId = session.user.id;
      const fileExt = file instanceof File ? file.name.split('.').pop() : (folder === 'audio' ? 'wav' : 'png');
      const fileName = `${userId}/${folder}/${Date.now()}.${fileExt}`;

      // 1. Upload to bucket
      const { error: uploadError } = await supabase.storage
        .from('media')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      // 2. Get Public URL
      const { data } = supabase.storage
        .from('media')
        .getPublicUrl(fileName);

      return data.publicUrl;
    } catch (err) {
      console.error("Upload failed:", err);
      return null;
    }
  }
};
