
import { supabase } from '../supabase';

export const dbService = {
  // 1. Update Profile Info and Assets
  async updateProfile(userId: string, updates: { full_name?: string, avatar_url?: string, odaa_assets?: number, baallii_assets?: number }) {
    try {
      const { error } = await supabase
        .from('profiles')
        .upsert({
          id: userId,
          ...updates,
          updated_at: new Date()
        });
      
      if (error) throw error;
      return true;
    } catch (err) {
      console.error("Profile update failed:", err);
      return false;
    }
  },

  // 2. Unified Analytics Logger
  async logAction(userId: string | null, action: string, amount: number = 1) {
    if (!userId) return;
    try {
      // Map frontend keys to DB column names if necessary
      const columnMap: Record<string, string> = {
        'audioCount': 'audio_count',
        'imageCount': 'image_count',
        'videoCount': 'video_count',
        'likes': 'like_count',
        'shares': 'share_count',
        'downloads': 'download_count',
        'clicks': 'click_count',
        'liveMinutes': 'live_minutes'
      };
      
      const col = columnMap[action] || action;

      await supabase.rpc('increment_stat', { 
        row_id: userId, 
        col_name: col,
        amount: amount
      });
    } catch (err) {
      console.warn("Analytics log failed:", err);
    }
  },

  // 3. Save AI Creation
  async saveCreation(userId: string, type: 'TTS' | 'IMAGE' | 'VIDEO', prompt: string, url: string) {
    try {
      const { data, error } = await supabase
        .from('creations')
        .insert([{ user_id: userId, type, prompt, result_url: url }]);
      
      if (error) throw error;

      const actionKey = type === 'TTS' ? 'audioCount' : type === 'IMAGE' ? 'imageCount' : 'videoCount';
      await this.logAction(userId, actionKey);

      return data;
    } catch (err) {
      console.warn("Creation save failed:", err);
      return null;
    }
  },

  // 4. Fetch Global Stats for About/Dashboard
  async getGlobalStats() {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('odaa_assets, baallii_assets, like_count, share_count, download_count, click_count, live_minutes');
      
      if (error) throw error;
      
      return data.reduce((acc, curr) => ({
        audioCount: 0, // Calculated from creations if needed
        imageCount: 0,
        videoCount: 0,
        likes: acc.likes + (curr.like_count || 0),
        shares: acc.shares + (curr.share_count || 0),
        downloads: acc.downloads + (curr.download_count || 0),
        clicks: acc.clicks + (curr.click_count || 0),
        liveMinutes: acc.liveMinutes + (curr.live_minutes || 0),
        giftPoints: acc.giftPoints + (curr.odaa_assets || 0) + (curr.baallii_assets || 0)
      }), { audioCount: 0, imageCount: 0, videoCount: 0, likes: 0, shares: 0, downloads: 0, clicks: 0, liveMinutes: 0, giftPoints: 0 });
    } catch (err) {
      return null;
    }
  }
};
