
import React, { useState, useEffect, useCallback } from 'react';
import Dashboard from './components/Dashboard';
import TTSSection from './components/TTSSection';
import ImageSection from './components/ImageSection';
import VideoSection from './components/VideoSection';
import LiveSection from './components/LiveSection';
import GiftSection from './components/GiftSection';
import AboutSection from './components/AboutSection';
import LoginOverlay from './components/LoginOverlay';
import PaymentSection from './components/PaymentSection';
import ProfileSection from './components/ProfileSection';
import ShareAwardButton from './components/ShareAwardButton';
import HelpChatbot from './components/HelpChatbot';
import { AppMode, Language, LanguageNames, UserStats } from './types';
import { supabase } from './supabase';
import { dbService } from './services/dbService';

const App: React.FC = () => {
  const [mode, setMode] = useState<AppMode>(AppMode.DASHBOARD);
  const [toast, setToast] = useState<string | null>(null);
  const [language, setLanguage] = useState<Language>(Language.ENGLISH);
  const [user, setUser] = useState<any>(null);
  const [isGuest, setIsGuest] = useState(false);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [hasPremiumAccess, setHasPremiumAccess] = useState<boolean>(() => {
    return localStorage.getItem('mohisa_premium') === 'true';
  });
  
  const [stats, setStats] = useState<UserStats>(() => {
    const saved = localStorage.getItem('mohisa_stats');
    return saved ? JSON.parse(saved) : {
      audioCount: 0, imageCount: 0, videoCount: 0, giftPoints: 500,
      likes: 0, shares: 0, downloads: 0, clicks: 0, liveMinutes: 0
    };
  });

  useEffect(() => {
    localStorage.setItem('mohisa_stats', JSON.stringify(stats));
  }, [stats]);

  useEffect(() => {
    localStorage.setItem('mohisa_premium', String(hasPremiumAccess));
  }, [hasPremiumAccess]);

  const incrementStat = useCallback((key: keyof UserStats, amount = 1) => {
    setStats(prev => ({ ...prev, [key]: (prev[key] as number) + amount }));
    if (user) dbService.logAction(user.id, key as any, amount);
  }, [user]);

  useEffect(() => {
    const savedLang = localStorage.getItem('mohisa_preferred_lang') as Language;
    if (savedLang) setLanguage(savedLang);
    
    const guestFlag = localStorage.getItem('mohisa_guest_session') === 'true';
    if (guestFlag) setIsGuest(true);

    const checkSession = async () => {
      try {
        const { data, error } = await supabase.auth.getSession();
        if (error) {
          if (guestFlag) setIsGuest(true);
        } else {
          setUser(data?.session?.user ?? null);
        }
      } catch (error) {
        setIsGuest(true);
      } finally {
        setIsAuthLoading(false);
      }
    };

    checkSession();
    incrementStat('clicks');

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, [incrementStat]);

  const handleModeChange = (newMode: AppMode) => {
    if (newMode === AppMode.VIDEO && !hasPremiumAccess) {
      setMode(AppMode.PAYMENT);
      showToast(language === Language.OROMO ? "Viidiyoo uumuuf dursa kaffaltii raawwadhaa! 💳" : "Please pay first to use Video AI! 💳");
    } else {
      setMode(newMode);
    }
    incrementStat('clicks');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNext = () => {
    const modes = Object.values(AppMode);
    const currentIndex = modes.indexOf(mode);
    const nextIndex = (currentIndex + 1) % modes.length;
    handleModeChange(modes[nextIndex]);
  };

  const handleBack = () => {
    const modes = Object.values(AppMode);
    const currentIndex = modes.indexOf(mode);
    const prevIndex = (currentIndex - 1 + modes.length) % modes.length;
    handleModeChange(modes[prevIndex]);
  };

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('mohisa_preferred_lang', lang);
    showToast(lang === Language.OROMO ? "Afaan jijjiirameera ✨" : "Language switched ✨");
  };

  const showToast = (message: string) => {
    setToast(message);
    setTimeout(() => setToast(null), 3000);
  };

  const logout = async () => {
    if (window.confirm(language === Language.OROMO ? "Gadi ba'uun gara seenuutti (login) deebi'uu barbaadduu?" : "Do you want to logout and return to login?")) {
      await supabase.auth.signOut();
      setUser(null);
      setIsGuest(false);
      localStorage.removeItem('mohisa_guest_session');
      setMode(AppMode.DASHBOARD);
      showToast(language === Language.OROMO ? "Milkaayinaan gadi baataniiru!" : "Logged out successfully!");
    }
  };

  const getModeLabel = (m: AppMode) => {
    const labels: Record<AppMode, Record<Language, string>> = {
      [AppMode.DASHBOARD]: { om: 'Mana (Home)', en: 'Home', sw: 'Nyumbani', so: 'Hoyga', ar: 'الرئيسية', am: 'ቤት', tr: 'Ana Sayfa', es: 'Inicio' },
      [AppMode.TTS]: { om: 'Sagalee AI', en: 'Voice AI', sw: 'Sauti AI', so: 'Codka AI', ar: 'صوت AI', am: 'ድምፅ AI', tr: 'Ses AI', es: 'Voz AI' },
      [AppMode.STT]: { om: 'Barreeffama', en: 'Transcribe', sw: 'Andika', so: 'Qoraal', ar: 'نسخ', am: 'ጽሑፍ', tr: 'Deşifre', es: 'Transcripción' },
      [AppMode.COMMUNICATION]: { om: 'Live Chat', en: 'Live Chat', sw: 'Mazungumzo', so: 'Wadahadal', ar: 'دردشة مباشرة', am: 'ቀጥታ ውይይት', tr: 'Canlı Sohbet', es: 'Chat en vivo' },
      [AppMode.IMAGE]: { om: 'Suuraa AI', en: 'Image AI', sw: 'Picha AI', so: 'Sawir AI', ar: 'صور AI', am: 'ምስል AI', tr: 'Resim AI', es: 'Resumen AI' },
      [AppMode.VIDEO]: { om: 'Viidiyoo', en: 'Video AI', sw: 'Video AI', so: 'Muuqaal AI', ar: 'فيديو AI', am: 'ቪዲዮ AI', tr: 'Video AI', es: 'Video AI' },
      [AppMode.GIFT]: { om: 'Kennaa', en: 'Gifts', sw: 'Zawadi', so: 'Hadiyado', ar: 'هدايا', am: 'ስጦታ', tr: 'Hediyeler', es: 'Regalos' },
      [AppMode.PAYMENT]: { om: 'Kaffaltii', en: 'Payment', sw: 'Malipo', so: 'Lacag-bixinta', ar: 'الدفع', am: 'ክፍያ', tr: 'Ödeme', es: 'Pago' },
      [AppMode.PROFILE]: { om: 'Profaayila', en: 'Profile', sw: 'Wasifu', so: 'Profile-ka', ar: 'الملف الشخصي', am: 'መገለጫ', tr: 'Profil', es: 'Perfil' },
      [AppMode.ABOUT]: { om: 'Waa\'ee App', en: 'About App', sw: 'Kuhusu', so: 'Ku saabsan', ar: 'حول التطبيق', am: 'ስለ መተግበሪያው', tr: 'Hakkında', es: 'Acerca de' }
    } as any;
    return (labels[m] as any)?.[language] || (labels[m] as any)?.[Language.ENGLISH] || m;
  };

  const renderContent = () => {
    switch (mode) {
      case AppMode.TTS:
        return <TTSSection onToggleToast={showToast} language={language} onNavigate={handleModeChange} setIsProcessing={setIsProcessing} incrementStat={incrementStat} initialTab="TTS" />;
      case AppMode.STT:
        return <TTSSection onToggleToast={showToast} language={language} onNavigate={handleModeChange} setIsProcessing={setIsProcessing} incrementStat={incrementStat} initialTab="STT" />;
      case AppMode.COMMUNICATION:
        return <LiveSection language={language} incrementStat={incrementStat} />;
      case AppMode.IMAGE:
        return <ImageSection onToggleToast={showToast} language={language} />;
      case AppMode.VIDEO:
        return <VideoSection onToggleToast={showToast} language={language} onNavigate={handleModeChange} />;
      case AppMode.GIFT:
        return <GiftSection onToggleToast={showToast} language={language} />;
      case AppMode.PAYMENT:
        return <PaymentSection onToggleToast={showToast} language={language} onPaymentSuccess={() => { setHasPremiumAccess(true); setMode(AppMode.DASHBOARD); }} />;
      case AppMode.PROFILE:
        return <ProfileSection language={language} />;
      case AppMode.ABOUT:
        return <AboutSection language={language} stats={stats} />;
      default:
        return null;
    }
  };

  const getHeaderTitle = () => {
    const titles: Record<AppMode, Record<Language, React.ReactNode>> = {
      [AppMode.DASHBOARD]: { om: <>MOHISA <span className="text-red-600">ORO</span></>, en: <>MOHISA <span className="text-red-600">ORO</span></> },
      [AppMode.TTS]: { om: <>SAGALEE <span className="text-red-600">AI</span></>, en: <>VOICE <span className="text-red-600">AI</span></> },
      [AppMode.STT]: { om: <>TRANSCRIBE <span className="text-red-600">AI</span></>, en: <>STT <span className="text-red-600">AI</span></> },
      [AppMode.COMMUNICATION]: { om: <>LIVE WALIN MOHISA</>, en: <>LIVE WITH MOHISA</> },
      [AppMode.IMAGE]: { om: <>SUURAA <span className="text-red-600">ORO</span></>, en: <>IMAGE <span className="text-red-600">ORO</span></> },
      [AppMode.VIDEO]: { om: <>VIDEO <span className="text-red-600">PREMIUM</span></>, en: <>VIDEO <span className="text-red-600">PREMIUM</span></> },
      [AppMode.GIFT]: { om: <>KENNAA</>, en: <>GIFTS</> },
      [AppMode.PAYMENT]: { om: <>KAFFALTII</>, en: <>PAYMENT</> },
      [AppMode.PROFILE]: { om: <>PROFAAYILA KOO</>, en: <>MY PROFILE</> },
      [AppMode.ABOUT]: { om: <>DHIMMA KOO</>, en: <>ABOUT</> }
    } as any;
    return titles[mode][language] || titles[mode][Language.ENGLISH];
  };

  if (isAuthLoading) return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <div className="flex flex-col items-center gap-6">
        <div className="w-16 h-16 border-4 border-slate-200 border-t-red-600 rounded-full animate-spin"></div>
        <p className="text-slate-400 font-black text-[10px] uppercase tracking-[0.4em]">Mohisa Oro Loading...</p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col relative overflow-x-hidden transition-all duration-1000">
      {!user && !isGuest && (
        <LoginOverlay 
          onLanguageChange={handleLanguageChange} 
          currentLanguage={language} 
          onGuestLogin={() => { setIsGuest(true); localStorage.setItem('mohisa_guest_session', 'true'); }}
        />
      )}
      
      {(user || isGuest) && (
        <>
          {/* HEADER NAV (PINNED) */}
          <nav className="fixed top-0 inset-x-0 z-[200] px-4 py-4 animate-slide-down">
            <div className="max-w-5xl mx-auto flex justify-between items-center bg-white/95 backdrop-blur-3xl border border-white/40 p-3 rounded-[2rem] shadow-2xl min-h-[70px]">
              {/* LOGO 'M' - LOGOUT TRIGGER */}
              <div 
                className="flex items-center gap-2 pl-2 cursor-pointer group shrink-0"
                onClick={logout}
                title={language === Language.OROMO ? "Gadi Ba'i" : "Logout"}
              >
                <div className="w-9 h-9 sm:w-11 sm:h-11 bg-black text-white rounded-full flex items-center justify-center font-black text-md sm:text-lg shadow-lg group-hover:bg-red-600 transition-all border-2 border-white ring-2 ring-transparent group-hover:ring-red-200">M</div>
                <div className="hidden md:flex flex-col">
                  <span className="font-black text-[9px] uppercase tracking-0.2em text-slate-900 leading-none group-hover:text-red-600 transition-colors">LOGOUT</span>
                  <span className="text-[7px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">
                    GADI BA'I
                  </span>
                </div>
              </div>

              {/* HEADER SELECTORS - LANGUAGE ONLY NOW */}
              <div className="flex items-center gap-2 sm:gap-4">
                
                {/* LANGUAGE SELECTOR CONTAINER */}
                <div className="relative group bg-slate-50 border border-slate-100 rounded-full shadow-sm px-4 py-1.5 flex items-center hover:border-black transition-all">
                   <select 
                     value={language}
                     onChange={(e) => handleLanguageChange(e.target.value as Language)}
                     className="appearance-none bg-transparent font-black text-[8px] sm:text-[10px] uppercase tracking-widest text-slate-900 outline-none cursor-pointer pr-6"
                   >
                     {Object.entries(LanguageNames).map(([code, name]) => (
                       <option key={code} value={code} className="text-black font-bold">{name}</option>
                     ))}
                   </select>
                   <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-[7px] text-slate-400">▼</div>
                </div>

                {/* PROFILE BUTTON */}
                <button 
                  onClick={() => handleModeChange(AppMode.PROFILE)}
                  className={`w-9 h-9 sm:w-12 sm:h-12 rounded-full flex items-center justify-center shadow-xl border-2 border-white overflow-hidden group hover:scale-110 transition-all shrink-0 ${mode === AppMode.PROFILE ? 'bg-red-600 text-white border-red-200' : 'bg-slate-100 text-slate-900'}`}
                >
                   <span className="text-lg sm:text-xl group-hover:scale-110 transition-transform">👤</span>
                </button>
              </div>
            </div>
          </nav>

          {/* MAIN CONTENT AREA */}
          <main className="flex-1 pt-24 px-4 sm:px-6 max-w-5xl mx-auto w-full pb-20 animate-in fade-in duration-1000 relative z-10">
            
            <div className="flex flex-col gap-6 sm:gap-10">
                
                {/* STANDALONE SECTION COMBO BOX */}
                <div className="glass-card rounded-[2rem] p-4 sm:p-6 bg-white/40 backdrop-blur-3xl border border-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl animate-in slide-in-from-top-4 duration-700">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-red-600 text-white rounded-xl flex items-center justify-center text-lg shadow-lg">🛠️</div>
                        <div className="text-left">
                           <h3 className="font-black text-[10px] uppercase tracking-[0.1em] text-slate-900">Filannoo Section</h3>
                           <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">{language === Language.OROMO ? 'Bakka itti deemuu barbaaddu filadhu' : 'Select where you want to go'}</p>
                        </div>
                    </div>
                    
                    <div className="w-full sm:w-64 relative group">
                        <select 
                            value={mode}
                            onChange={(e) => handleModeChange(e.target.value as AppMode)}
                            className="w-full appearance-none bg-black text-white px-6 py-3 rounded-xl font-black text-[9px] sm:text-[11px] uppercase tracking-[0.1em] outline-none cursor-pointer pr-10 shadow-2xl transition-all hover:bg-red-600 border-b-4 border-slate-800 active:translate-y-0.5"
                        >
                            {Object.values(AppMode).map((m) => (
                                <option key={m} value={m} className="bg-white text-black font-bold">{getModeLabel(m)}</option>
                            ))}
                        </select>
                        <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-[8px] text-white/50">▼</div>
                    </div>
                </div>

                {/* 1. COMPONENT CONTENT SECTION */}
                <div className="min-h-[300px] animate-in slide-in-from-top-8 duration-1000">
                    {mode === AppMode.DASHBOARD ? (
                        <Dashboard onNavigate={handleModeChange} currentLanguage={language} onLanguageChange={handleLanguageChange} />
                    ) : (
                        <div className="space-y-4 sm:space-y-6">
                           <div className="text-center">
                              <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tighter uppercase italic">{getHeaderTitle()}</h2>
                              <div className="h-1 w-10 bg-red-600/20 mx-auto mt-1 rounded-full"></div>
                           </div>
                           {renderContent()}
                        </div>
                    )}
                </div>

                {/* 2. BEAUTIFUL MARQUEE & MINI CONTROLS SECTION */}
                <div className="w-full max-w-4xl mx-auto space-y-4">
                  
                  {/* COMPACT MINI CONTROLS (NEXT/BACK) */}
                  <div className="flex items-center justify-between gap-4 px-2">
                    <button 
                      onClick={handleBack}
                      className="flex-1 bg-black text-white py-3 rounded-xl font-black text-[8px] uppercase tracking-widest shadow-xl border-b-4 border-slate-900 hover:bg-red-600 transition-all active:translate-y-0.5 flex items-center justify-center gap-2 group"
                    >
                      <span className="group-hover:-translate-x-1 transition-transform">⬅️</span>
                      {language === Language.OROMO ? 'DUUBATTI' : 'BACK'}
                    </button>
                    <button 
                      onClick={handleNext}
                      className="flex-1 bg-red-600 text-white py-3 rounded-xl font-black text-[8px] uppercase tracking-widest shadow-xl border-b-4 border-red-900 hover:bg-black transition-all active:translate-y-0.5 flex items-center justify-center gap-2 group"
                    >
                      {language === Language.OROMO ? 'ITTI FUFI' : 'NEXT'}
                      <span className="group-hover:translate-x-1 transition-transform">➡️</span>
                    </button>
                  </div>

                  {/* STYLISH SCROLLING MARQUEE */}
                  <div className="relative w-full h-14 bg-black rounded-[1.5rem] overflow-hidden flex items-center shadow-2xl border-b-4 border-slate-900 group">
                    <div className="absolute inset-y-0 left-0 w-12 bg-gradient-to-r from-black to-transparent z-10"></div>
                    <div className="absolute inset-y-0 right-0 w-12 bg-gradient-to-l from-black to-transparent z-10"></div>
                    
                    <div className="flex items-center whitespace-nowrap animate-marquee-text gap-10">
                      <span className="text-white font-black text-[10px] uppercase tracking-[0.25em] italic">
                        MOHISA ORO AI DEVELOPED BY MOHAMMED ISA ACHIEVE YOUR DREAM BY USING THIS APP
                      </span>
                      <span className="text-red-500 font-black text-[10px] uppercase tracking-[0.25em] italic">
                        MOHISA ORO AI DEVELOPED BY MOHAMMED ISA ACHIEVE YOUR DREAM BY USING THIS APP
                      </span>
                      <span className="text-white font-black text-[10px] uppercase tracking-[0.25em] italic">
                        MOHISA ORO AI DEVELOPED BY MOHAMMED ISA ACHIEVE YOUR DREAM BY USING THIS APP
                      </span>
                      <span className="text-red-500 font-black text-[10px] uppercase tracking-[0.25em] italic">
                        MOHISA ORO AI DEVELOPED BY MOHAMMED ISA ACHIEVE YOUR DREAM BY USING THIS APP
                      </span>
                    </div>
                  </div>
                </div>
            </div>
            
            <footer className="mt-8 text-center pb-10 border-t border-black/5 pt-10">
               <p className="text-[8px] font-black text-slate-300 uppercase tracking-[0.5em] italic">MOHISA ORO AI • Mohammed Isa 2026</p>
            </footer>
          </main>

          {/* BOTTOM DOCK (CENTERED) */}
          <div className="fixed bottom-4 sm:bottom-6 inset-x-0 z-[140] px-4 pointer-events-none">
            <div className="max-w-3xl mx-auto bg-black/90 backdrop-blur-2xl border border-white/20 p-1.5 rounded-full shadow-[0_20px_40px_-10px_rgba(0,0,0,0.5)] flex justify-between items-center overflow-x-auto no-scrollbar pointer-events-auto">
              {[
                { mode: AppMode.DASHBOARD, icon: '🏠' },
                { mode: AppMode.TTS, icon: '🎙️' },
                { mode: AppMode.COMMUNICATION, icon: '💬' },
                { mode: AppMode.IMAGE, icon: '🎨' },
                { mode: AppMode.VIDEO, icon: '🎬', premium: !hasPremiumAccess },
                { mode: AppMode.GIFT, icon: '🎁' },
                { mode: AppMode.PROFILE, icon: '👤' },
              ].map((item) => (
                <button
                  key={item.mode}
                  onClick={() => handleModeChange(item.mode)}
                  className={`flex items-center justify-center w-11 h-11 sm:w-13 sm:h-13 rounded-full transition-all group relative shrink-0 ${
                    mode === item.mode 
                    ? 'bg-red-600 text-white shadow-2xl scale-110' 
                    : 'text-slate-400 hover:text-white hover:scale-110'
                  }`}
                >
                  <span className="text-lg sm:text-xl transition-transform group-hover:scale-125">{item.icon}</span>
                </button>
              ))}
            </div>
          </div>

          {/* CHATBOT */}
          <div className="fixed bottom-4 left-4 sm:bottom-8 sm:left-8 z-[600]">
              <HelpChatbot language={language} />
          </div>

          {/* SHARE APP */}
          <div className="fixed bottom-4 right-4 sm:bottom-8 sm:right-8 z-[600]">
              <ShareAwardButton language={language} />
          </div>

          {toast && (
            <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[1000] toast-enter">
              <div className="bg-black text-white px-6 sm:px-8 py-2.5 sm:py-3 rounded-full font-black text-[9px] sm:text-[10px] uppercase tracking-widest shadow-2xl border border-white/20 backdrop-blur-md">
                {toast}
              </div>
            </div>
          )}
        </>
      )}

      <style>{`
        @keyframes marquee-text {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-marquee-text {
          animation: marquee-text 15s linear infinite;
        }
        .animate-marquee-text:hover {
          animation-play-state: paused;
        }
      `}</style>
    </div>
  );
};

export default App;
