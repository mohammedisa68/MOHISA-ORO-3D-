
export interface AudioData {
  blob?: Blob;
  url: string;
  timestamp: number;
  text: string;
}

export interface ImageData {
  url: string;
  timestamp: number;
  prompt: string;
}

export interface VideoData {
  url: string;
  timestamp: number;
  prompt: string;
}

export interface GiftItem {
  id: string;
  name: string;
  price: number;
  owner: string;
  type: string;
  imageUrl: string;
}

export interface UserStats {
  audioCount: number;
  imageCount: number;
  videoCount: number;
  giftPoints: number;
  likes: number;
  shares: number;
  downloads: number;
  clicks: number;
  liveMinutes: number;
}

export enum AppMode {
  DASHBOARD = 'DASHBOARD',
  TTS = 'TTS',
  STT = 'STT',
  COMMUNICATION = 'COMMUNICATION',
  IMAGE = 'IMAGE',
  VIDEO = 'VIDEO',
  GIFT = 'GIFT',
  PAYMENT = 'PAYMENT',
  PROFILE = 'PROFILE',
  ABOUT = 'ABOUT'
}

export enum VoiceType {
  MALE = 'Charon',
  FEMALE = 'Kore',
  CHILD = 'Puck',
  ELDER = 'Fenrir'
}

export enum Language {
  OROMO = 'om',
  ENGLISH = 'en',
  ARABIC = 'ar',
  AMHARIC = 'am',
  SWAHILI = 'sw',
  SOMALI = 'so',
  TURKISH = 'tr',
  SPANISH = 'es'
}

export const LanguageNames: Record<Language, string> = {
  [Language.OROMO]: 'Afaan Oromoo',
  [Language.ENGLISH]: 'English',
  [Language.ARABIC]: 'Arabic (العربية)',
  [Language.AMHARIC]: 'Amharic (አማርኛ)',
  [Language.SWAHILI]: 'Swahili (Kiswahili)',
  [Language.SOMALI]: 'Somali (Af-Soomaali)',
  [Language.TURKISH]: 'Turkish (Türkçe)',
  [Language.SPANISH]: 'Spanish (Español)'
};
