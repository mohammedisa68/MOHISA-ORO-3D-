
-- 1. PROFILES TABLE
-- Stores user identity and heritage assets (Odaa/Baallii)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID REFERENCES auth.users NOT NULL PRIMARY KEY,
  full_name TEXT,
  avatar_url TEXT,
  odaa_assets INTEGER DEFAULT 0,
  baallii_assets INTEGER DEFAULT 0,
  click_count INTEGER DEFAULT 0,
  share_count INTEGER DEFAULT 0,
  download_count INTEGER DEFAULT 0,
  like_count INTEGER DEFAULT 0,
  live_minutes INTEGER DEFAULT 0,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. CREATIONS TABLE
-- Tracks AI generated media links
CREATE TABLE IF NOT EXISTS public.creations (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  type TEXT NOT NULL, -- 'TTS', 'IMAGE', 'VIDEO'
  prompt TEXT,
  result_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. ENABLE RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.creations ENABLE ROW LEVEL SECURITY;

-- 4. PROFILE POLICIES
CREATE POLICY "Users can view their own profile" 
ON public.profiles FOR SELECT 
USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" 
ON public.profiles FOR UPDATE 
USING (auth.uid() = id);

CREATE POLICY "Allow individual insert during signup" 
ON public.profiles FOR INSERT 
WITH CHECK (auth.uid() = id);

-- 5. CREATIONS POLICIES
CREATE POLICY "Users can view their own creations" 
ON public.creations FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own creations" 
ON public.creations FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- 6. ANALYTICS FUNCTION
-- Safely increments stats like likes, clicks, or assets
CREATE OR REPLACE FUNCTION increment_stat(row_id UUID, col_name TEXT, amount INTEGER DEFAULT 1)
RETURNS void AS $$
BEGIN
  EXECUTE format('UPDATE public.profiles SET %I = %I + $1, updated_at = NOW() WHERE id = $2', col_name, col_name)
  USING amount, row_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 7. STORAGE BUCKETS
-- Run these in the Supabase Dashboard or via API
-- Ensure a bucket named 'media' exists.
-- Policy for Storage:
-- CREATE POLICY "User media access" ON storage.objects FOR ALL 
-- USING (bucket_id = 'media' AND auth.uid()::text = (storage.foldername(name))[1]);
